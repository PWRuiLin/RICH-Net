import glob
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
import config as c
from natsort import natsorted
def to_rgb(image):
    rgb_image = Image.new("RGB", image.size)
    rgb_image.paste(image)
    return rgb_image

class Hinet_Dataset(Dataset):
    def __init__(self, transforms_=None, mode="train"):

        self.transform = transforms_
        self.mode = mode
        if self.mode == "train":
            # TRAIN SETTING
            if c.Dataset_TRAIN_mode == 'CelebA-HQ':
                self.TRAIN_PATH = c.TRAIN_PATH_CelebAHQ
                self.format_train = 'jpg'
                print('TRAIN DATASET is CelebA-HQ')
            if c.Dataset_TRAIN_mode == 'DIV2K':
                self.TRAIN_PATH = c.TRAIN_PATH_DIV2K
                self.format_train = 'png'
                print('TRAIN DATASET is DIV2K')
            if c.Dataset_TRAIN_mode == 'CelebA':
                self.TRAIN_PATH = c.TRAIN_PATH_CelebA
                self.format_train = 'jpg'
                print('TRAIN DATASET is CelebA')

            # train
            self.files = natsorted(sorted(glob.glob(self.TRAIN_PATH + "/*." + self.format_train)))

        if self.mode == "valid":
            # VAL SETTING
            if c.Dataset_VALID_mode == 'CelebA-HQ':
                self.VALID_PATH = c.VALID_PATH_CelebAHQ
                self.format_valid = 'jpg'
                print('VALID DATASET is CelebA-HQ')
            if c.Dataset_VALID_mode == 'DIV2K':
                self.VALID_PATH = c.VALID_PATH_DIV2K
                self.format_valid = 'png'
                print('VALID DATASET is DIV2K')
            if c.Dataset_VALID_mode == 'CelebA':
                self.VALID_PATH = c.VALID_PATH_CelebA
                self.format_valid = 'jpg'
                print('VALID DATASET is CelebA')

            # valid
            self.files = natsorted(sorted(glob.glob(self.VALID_PATH + "/*." + self.format_valid)))

        if self.mode == "test":
            # TEST SETTING
            if c.Dataset_TEST_mode == 'CelebA-HQ':
                self.TEST_PATH = c.TEST_PATH_CelebAHQ
                self.format_test = 'png'
                print('TEST DATASET is CelebA-HQ')
            if c.Dataset_TEST_mode == '4Datasets':
                self.TEST_PATH = c.TEST_PATH_4Datasets
                self.format_test = 'png'
                print('TEST DATASET is 4Datasets')
            if c.Dataset_TEST_mode == 'DIV2K':
                self.TEST_PATH = c.TEST_PATH_DIV2K
                self.format_test = 'png'
                print('TEST DATASET is DIV2K')

            if c.Dataset_TEST_mode == 'CelebA':
                self.TEST_PATH = c.TEST_PATH_CelebA
                self.format_test = 'png'
                print('TEST DATASET is CelebA')

            if c.Dataset_TEST_mode == 'LFW':
                self.TEST_PATH = c.TEST_PATH_LFW
                self.format_test = 'png'
                print('TEST DATASET is LFW')

            if c.Dataset_TEST_mode == 'FFHQ':
                self.TEST_PATH = c.TEST_PATH_FFHQ
                self.format_test = 'png'
                print('TEST DATASET is FFHQ')
            if c.Dataset_TEST_mode == 'AGE_ADULTS':
                self.TEST_PATH = c.TEST_PATH_AGE_ADULTS
                self.format_test = 'png'
                print('TEST DATASET is AGE_ADULTS')

            if c.Dataset_TEST_mode == 'experiment1_8':
                self.TEST_PATH = c.TEST_PATH_experiment1_8
                self.format_test = 'jpg'
                print('TEST DATASET is experiment1_8')

            if c.Dataset_TEST_mode == 'experiment1_2':
                self.TEST_PATH = c.TEST_PATH_experiment1_2
                self.format_test = 'png'
                print('TEST DATASET is experiment1_2')

            if c.Dataset_TEST_mode == 'experiment2':
                self.TEST_PATH = c.TEST_PATH_experiment2
                self.format_test = 'jpg'
                print('TEST DATASET is experiment2')

            if c.Dataset_TEST_mode == 'experiment3':
                self.TEST_PATH = c.TEST_PATH_experiment3
                self.format_test = 'png'
                print('TEST DATASET is experiment3')
            # valid
            self.files = natsorted(sorted(glob.glob(self.TEST_PATH + "/*." + self.format_test)))
    def __getitem__(self, index):
        try:
                image = Image.open(self.files[index])
                image = to_rgb(image)
                item = self.transform(image)
                return item

        except:
            return self.__getitem__(index + 1)

    def __len__(self):
        return len(self.files)


if c.Dataset_VALID_mode == 'CelebA-HQ':
    cropsize_valid = c.cropsize_valid_CelebAHQ
if c.Dataset_VALID_mode == 'CelebA':
    cropsize_valid = c.cropsize_valid_CelebA
if c.Dataset_VALID_mode == 'LFW':
    cropsize_valid = c.cropsize_valid_LFW

transform = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomCrop(c.cropsize_train),
    # T.Resize(c.resize_train),
    T.ToTensor()
])

transform_valid = T.Compose([
    T.CenterCrop(c.cropsize_valid),
    # T.CenterCrop(c.cropsize_train),
    T.ToTensor(),
])

transform_test = T.Compose([
    T.Resize(c.resize_test),
    # T.CenterCrop(c.cropsize_test),
    T.ToTensor(),
])
# Training data loader
import os
print('cpu', os.cpu_count())  # 返回逻辑处理器的总数（包括超线程）

trainloader = DataLoader(
    Hinet_Dataset(transforms_=transform, mode="train"),
    batch_size=c.batch_size_train,
    shuffle=False,
    pin_memory=True,
    num_workers=24,
    drop_last=True
)
# Valid data loader
validloader = DataLoader(
    Hinet_Dataset(transforms_=transform_valid, mode="valid"),
    batch_size=c.batchsize_valid,
    shuffle=False,
    pin_memory=True,
    num_workers=24,
    drop_last=True
)
# Test data loader
testloader = DataLoader(
    Hinet_Dataset(transforms_=transform_test, mode="test"),
    batch_size=c.batchsize_test,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)

import os
import cv2
print(os.cpu_count())  # 返回逻辑处理器的总数（包括超线程）
def dataset(A, B, C):
    dataset_A_path = A
    dataset_B_path = B
    dataset_C_path = C
    #确保保存结果的目录存在
    os.makedirs(dataset_C_path, exist_ok=True)
    # 遍历数据集A
    for i, filename in enumerate(os.listdir(dataset_A_path)):
        img_A = cv2.imread(os.path.join(dataset_A_path, filename))
        new_filename = '{:05d}.png'.format(2 * i + 1)
        cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_A)
    # 遍历数据集B
    for i, filename in enumerate(os.listdir(dataset_B_path)):
        img_B = cv2.imread(os.path.join(dataset_B_path, filename))
        new_filename = '{:05d}.png'.format(2 * i +2)
        cv2.imwrite(os.path.join(dataset_C_path, new_filename), img_B)
    print('OK')

# A = './Dataset/AGE_ADULTS/anonymization_face/'
# B = './Dataset/AGE_ADULTS/protected_face/'
# C = './Dataset/AGE_ADULTS/test_HighQuality/'
# dataset(A, B, C)
if __name__ == '__main__':
    print('len(trainloader)=',len(trainloader))
    print('len(validloader)=', len(validloader))
    print('len(testloader)=',len(testloader))
    # for i_batch, data in enumerate(trainloader):
    #     print("trainloader成功")
    # for i_batch, data in enumerate(testloader):
    #     print("testloader成功")