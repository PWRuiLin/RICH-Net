from other_method.GenRAN_main.IFAG.FAG.detection.detection_api import BaseDetector, RCNNDetector, ImageAnnotation
from other_method.GenRAN_main.IFAG.FAG.detection.build import build_detector
