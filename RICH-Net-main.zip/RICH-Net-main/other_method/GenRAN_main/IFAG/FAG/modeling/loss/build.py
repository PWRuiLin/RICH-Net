from other_method.GenRAN_main.IFAG.FAG.utils import Registry

CRITERION_REGISTRY = Registry("CRITERION")
