import os
import cv2
import argparse
import glob
import torch
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import torchvision
from torchvision.transforms.functional import normalize
from other_method.GenRAN_main.IFAG.FRM.basicsr.utils import img2tensor, tensor2img
from other_method.GenRAN_main.IFAG.FRM.basicsr.utils.download_util import load_file_from_url
from other_method.GenRAN_main.IFAG.FRM.basicsr.utils.misc import gpu_is_available, get_device
from other_method.GenRAN_main.IFAG.FRM.facelib.utils.face_restoration_helper import FaceRestoreHelper
from other_method.GenRAN_main.IFAG.FRM.facelib.utils.misc import is_gray

from other_method.GenRAN_main.IFAG.FRM.basicsr.utils.registry import ARCH_REGISTRY
import torchvision.transforms as transforms

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
pretrain_model_url = {
    'restoration': 'https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/codeformer.pth',
}
def set_realesrgan():
    from basicsr.archs.rrdbnet_arch import RRDBNet
    from basicsr.utils.realesrgan_utils import RealESRGANer

    use_half = False
    if torch.cuda.is_available():  # set False in CPU/MPS mode
        no_half_gpu_list = ['1650', '1660']  # set False for GPUs that don't support f16
        if not True in [gpu in torch.cuda.get_device_name(0) for gpu in no_half_gpu_list]:
            use_half = True

    model = RRDBNet(
        num_in_ch=3,
        num_out_ch=3,
        num_feat=64,
        num_block=23,
        num_grow_ch=32,
        scale=2,
    )
    upsampler = RealESRGANer(
        scale=2,
        model_path="https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/RealESRGAN_x2plus.pth",
        model=model,
        tile=args.bg_tile,
        tile_pad=40,
        pre_pad=0,
        half=use_half
    )

    if not gpu_is_available():  # CPU
        import warnings
        warnings.warn('Running on CPU now! Make sure your PyTorch version matches your CUDA.'
                      'The unoptimized RealESRGAN is slow on CPU. '
                      'If you want to disable it, please remove `--bg_upsampler` and `--face_upsample` in command.',
                      category=RuntimeWarning)
    return upsampler


# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
device = get_device()
parser = argparse.ArgumentParser()
# parser.add_argument('-i', '--input_path', type=str, default='./inputs/whole_imgs',
#             help='Input image, video or folder. Default: inputs/whole_imgs')
# parser.add_argument('-o', '--output_path', type=str, default=None,
#             help='Output folder. Default: results/<input_name>_<w>')
parser.add_argument('-w', '--fidelity_weight', type=float, default=0.5,
                    help='Balance the quality and fidelity. Default: 0.5')
parser.add_argument('-s', '--upscale', type=int, default=2,
                    help='The final upsampling scale of the image. Default: 2')
parser.add_argument('--has_aligned', action='store_true',
                    help='Input are cropped and aligned faces. Default: False')
parser.add_argument('--only_center_face', action='store_true',
                    help='Only restore the center face. Default: False')
parser.add_argument('--draw_box', action='store_true',
                    help='Draw the bounding box for the detected faces. Default: False')
# large det_model: 'YOLOv5l', 'retinaface_resnet50'
# small det_model: 'YOLOv5n', 'retinaface_mobile0.25'
parser.add_argument('--detection_model', type=str, default='retinaface_resnet50',
                    help='Face detector. Optional: retinaface_resnet50, retinaface_mobile0.25, YOLOv5l, YOLOv5n, dlib. \
            Default: retinaface_resnet50')
parser.add_argument('--bg_upsampler', type=str, default='None',
                    help='Background upsampler. Optional: realesrgan')
parser.add_argument('--face_upsample', action='store_true',
                    help='Face upsampler after enhancement. Default: False')
parser.add_argument('--bg_tile', type=int, default=400, help='Tile size for background sampler. Default: 400')
parser.add_argument('--suffix', type=str, default=None, help='Suffix of the restored faces. Default: None')

args = parser.parse_args()
# ------------------------ input & output ------------------------
w = args.fidelity_weight
# ------------------ set up background upsampler ------------------
if args.bg_upsampler == 'realesrgan':
    bg_upsampler = set_realesrgan()
else:
    bg_upsampler = None
# ------------------ set up face upsampler ------------------
if args.face_upsample:
    if bg_upsampler is not None:
        face_upsampler = bg_upsampler
    else:
        face_upsampler = set_realesrgan()
else:
    face_upsampler = None
# ------------------ set up CodeFormer restorer -------------------
net = ARCH_REGISTRY.get('CodeFormer')(dim_embd=512, codebook_size=1024, n_head=8, n_layers=9,
                                      connect_list=['32', '64', '128', '256']).to(device)
# ckpt_path = 'weights/CodeFormer/codeformer.pth'
ckpt_path = load_file_from_url(url=pretrain_model_url['restoration'],
                               model_dir='/home/WRL/WRL/RFA-Net/IFAG/FRM/weights/CodeFormer', progress=True, file_name=None)
checkpoint = torch.load(ckpt_path)['params_ema']
net.load_state_dict(checkpoint)
net.eval()
# ------------------ set up FaceRestoreHelper -------------------
# large det_model: 'YOLOv5l', 'retinaface_resnet50'
# small det_model: 'YOLOv5n', 'retinaface_mobile0.25'
if not args.has_aligned:
    print(f'Face detection model: {args.detection_model}')
if bg_upsampler is not None:
    print(f'Background upsampling: True, Face upsampling: {args.face_upsample}')
else:
    print(f'Background upsampling: False, Face upsampling: {args.face_upsample}')
face_helper = FaceRestoreHelper(
    args.upscale,
    face_size=512,
    crop_ratio=(1, 1),
    det_model=args.detection_model,
    save_ext='png',
    use_parse=True,
    device=device)
def FRM(IMAGE_TEST_PATH_transit_place):
    # -------------------- start to processing ---------------------
    # clean all the intermediate results to process the next image
    face_helper.clean_all()
    anonymization_face = cv2.imread(IMAGE_TEST_PATH_transit_place, cv2.IMREAD_COLOR)
    anonymization_face_shape = anonymization_face.shape
    face_helper.read_image(anonymization_face)
    # get face landmarks for each face
    num_det_faces = face_helper.get_face_landmarks_5(
        only_center_face=args.only_center_face, resize=640, eye_dist_threshold=5)
    print(f'\tdetect {num_det_faces} faces')
    # align and warp each face
    face_helper.align_warp_face()

    # face restoration for each cropped face
    for idx, cropped_face in enumerate(face_helper.cropped_faces):
        # prepare data
        cropped_face_t = img2tensor(cropped_face / 255., bgr2rgb=True, float32=True)
        normalize(cropped_face_t, (0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True)
        cropped_face_t = cropped_face_t.unsqueeze(0).to(device)

        try:
            with torch.no_grad():
                output = net(cropped_face_t, w=w, adain=True)[0]
                restored_face = tensor2img(output, rgb2bgr=True, min_max=(-1, 1))
            del output
            torch.cuda.empty_cache()
        except Exception as error:
            print(f'\tFailed inference for CodeFormer: {error}')
            restored_face = tensor2img(cropped_face_t, rgb2bgr=True, min_max=(-1, 1))

        restored_face = restored_face.astype('uint8')
        face_helper.add_restored_face(restored_face, cropped_face)
    transform = transforms.Compose([
        transforms.Resize((anonymization_face_shape[0], anonymization_face_shape[1])),
        transforms.ToTensor()  # 转换为张量
    ])
    # paste_back
    if not args.has_aligned:
        # upsample the background
        if bg_upsampler is not None:
            # Now only support RealESRGAN for upsampling background
            bg_img = bg_upsampler.enhance(anonymization_face, outscale=args.upscale)[0]
        else:
            bg_img = None
        face_helper.get_inverse_affine(None)
        # paste each restored face to the input image
        if args.face_upsample and face_upsampler is not None:
            restored_img = face_helper.paste_faces_to_input_image(upsample_img=bg_img, draw_box=args.draw_box,
                                                                  face_upsampler=face_upsampler)
        else:
            restored_img = face_helper.paste_faces_to_input_image(upsample_img=bg_img, draw_box=args.draw_box)
            restored_img = transform(Image.fromarray(cv2.cvtColor(restored_img, cv2.COLOR_RGB2BGR))).unsqueeze(0)
            # plt.imshow(np.squeeze(restored_img.permute(0, 2, 3, 1)))
            # plt.axis('off')
            # plt.show()
            return restored_img


