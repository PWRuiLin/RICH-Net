import torchvision
import numpy as np
import torchvision.transforms as transforms
from other_method.GenRAN_main.IFAG.FAG.FAG_TEST import FAG
from other_method.GenRAN_main.IFAG.FRM.FRM_TEST import FRM

import config as C
transform = transforms.Compose([
    transforms.ToTensor()  # 转换为张量
])
def IFAG(protected_face):
    torchvision.utils.save_image(protected_face, '/media/WRL/D/WRL/HiNet_Robust_main/other_method/GenRAN_main/image/'+'transit_place.png')
    anonymization_face_list = FAG('/media/WRL/D/WRL/HiNet_Robust_main/other_method/GenRAN_main/image/')
    anonymization_face = np.copy(anonymization_face_list[0])
    anonymization_face = transform(anonymization_face).unsqueeze(0)  # 添加批次维度
    torchvision.utils.save_image(anonymization_face, '/media/WRL/D/WRL/HiNet_Robust_main/other_method/GenRAN_main/image/' + 'transit_place.png')
    # anonymization_face_list = FAG(C.IMAGE_TEST_PATH_transit_place)
    # anonymization_face = np.copy(anonymization_face_list[0])
    # anonymization_face = transform(anonymization_face).unsqueeze(0)  # 添加批次维度
    # torchvision.utils.save_image(anonymization_face, C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    anonymization_face_enhanced = FRM('/media/WRL/D/WRL/HiNet_Robust_main/other_method/GenRAN_main/image/' + 'transit_place.png')
    return anonymization_face, anonymization_face_enhanced

    # torchvision.utils.save_image(protected_face, C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    # protected_face_enhanced = FRM(C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    # anonymization_face_list = FAG(C.IMAGE_TEST_PATH_transit_place)
    # anonymization_face = np.copy(anonymization_face_list[0])
    # anonymization_face = transform(anonymization_face).unsqueeze(0)  # 添加批次维度
    # torchvision.utils.save_image(anonymization_face, C.IMAGE_TEST_PATH_transit_place + 'transit_place.png')
    # return protected_face_enhanced, anonymization_face