import time
import cv2
import threading
import queue
import torch
import torchvision
import torch.optim
import multiprocessing
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from Dataset import datasets
import config as C
import numpy as np
from RFHN.RFHN_TEST import RFHN, RFHN_en, RFHN_de
from IFAG.IFAG_TEST import IFAG, IFAG1
from evaluation_metrics.calculate_PSNR_SSIM import calculate_PSNR_SSIM
from evaluation_metrics.calculate_APD_RMSE import calculate_APD_RMSE_MAE
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
transform = transforms.Compose([
    transforms.ToTensor()  # 转换为张量
])

H=400
W=400
fps = 20
show_text_R_OK = False# 定义全局变量
start_time = 0  # 定义全局变量
def test_anonymized(protected_face, img_format='png'):
    with torch.no_grad():
        T_start = time.time()
        # for i_batch, protected_face in enumerate(datasets.testloader):
        protected_face = protected_face.to(device)
        # print(protected_face.shape)
        anonymization_face, anonymization_face_enhanced = IFAG(protected_face)
        # print(anonymization_face_enhanced.shape)
        anonymization_face_img, protected_face_img, anonymized_face_img, lost_r_img = RFHN_en(anonymization_face_enhanced, protected_face, model='model_141_fmmrdb_best.pth')
        # protected_enhanced_face_img = protected_face_enhanced
        T_end = time.time()
        torchvision.utils.save_image(protected_face_img, C.IMAGE_TEST_PATH_protected + '%.d.' % 1 + img_format)
        # torchvision.utils.save_image(protected_enhanced_face_img, C.IMAGE_TEST_PATH_protected_enhanced + '%.d.' % i_batch + img_format)
        torchvision.utils.save_image(anonymization_face_img, C.IMAGE_TEST_PATH_anonymization + '%.d.' % 1 + img_format)
        torchvision.utils.save_image(anonymized_face_img, C.IMAGE_TEST_PATH_anonymized + '%.d.' % 1 + img_format)
        torchvision.utils.save_image(lost_r_img, C.IMAGE_TEST_PATH_lost + '%.d.' % 1 + img_format)
        T_anonymized = T_end - T_start
        print(f'T_anonymized = {T_anonymized}')
    # PSNR_all = []; SSIM_all = []
    # PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
    # MAE_all = []; RMSE_all = []; MAE = []
    # MAE_all, RMSE_all, MAE = calculate_APD_RMSE_MAE(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
    return protected_face_img, anonymized_face_img, lost_r_img

def test_anonymized1(protected_face, img_format='png'):
    with torch.no_grad():
        T_start = time.time()
        # for i_batch, protected_face in enumerate(datasets.testloader):
        protected_face = protected_face.to(device)
        # print(protected_face.shape)
        anonymization_face, anonymization_face_enhanced = IFAG1(protected_face)
        # print(anonymization_face_enhanced.shape)
        anonymization_face_img, protected_face_img, anonymized_face_img, lost_r_img = RFHN_en(anonymization_face_enhanced, protected_face, model='model_141_fmmrdb_best.pth')
        # protected_enhanced_face_img = protected_face_enhanced
        T_end = time.time()
        torchvision.utils.save_image(protected_face_img, C.IMAGE_TEST_PATH_protected + '%.d.' % 1 + img_format)
        # torchvision.utils.save_image(protected_enhanced_face_img, C.IMAGE_TEST_PATH_protected_enhanced + '%.d.' % i_batch + img_format)
        torchvision.utils.save_image(anonymization_face_img, C.IMAGE_TEST_PATH_anonymization + '%.d.' % 1 + img_format)
        torchvision.utils.save_image(anonymized_face_img, C.IMAGE_TEST_PATH_anonymized + '%.d.' % 1 + img_format)
        torchvision.utils.save_image(lost_r_img, C.IMAGE_TEST_PATH_lost + '%.d.' % 1 + img_format)
        T_anonymized = T_end - T_start
        print(f'T_anonymized = {T_anonymized}')
    # PSNR_all = []; SSIM_all = []
    # PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
    # MAE_all = []; RMSE_all = []; MAE = []
    # MAE_all, RMSE_all, MAE = calculate_APD_RMSE_MAE(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
    return protected_face_img, anonymized_face_img, lost_r_img

def test_recovered(anonymized_face_img, lost_r_img, img_format='png'):
    with torch.no_grad():
        T_start = time.time()
        protected_face_rev_img = RFHN_de(anonymized_face_img, lost_r_img, model='model_141_fmmrdb_best.pth')
        T_end = time.time()
        torchvision.utils.save_image(protected_face_rev_img, C.IMAGE_TEST_PATH_protected_rev + '%.d.' % 1 + img_format)
        T_recovered = T_end - T_start
        print(f'T_recovered = {T_recovered}')
    # PSNR_all = []; SSIM_all = []
    # PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
    # MAE_all = []; RMSE_all = []; MAE = []
    # MAE_all, RMSE_all, MAE = calculate_APD_RMSE_MAE(test_Y=True, secret=False, cover=True, img=img_format)
    # print(f' cover | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
    return protected_face_rev_img

class SharedState:# 创建一个共享的状态类
    def __init__(self):
        self.anonymized_face_img = None
        self.lost_r_img = None
        self.lock = threading.Lock()

def anonymiz_image(frame, num, output_queue, state):
    resized_RGB_frame = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), (H, W))
    protected_face = torch.tensor(resized_RGB_frame).permute(2, 0, 1).unsqueeze(0).clamp(0, 255).byte() / 255.0
    protected_face_img, anonymized_face_img, lost_r_img  = test_anonymized(protected_face, img_format='png')
    print(f"Anonymized and saved successfully! Frame saved as '{num}.png'")
    with state.lock:    # 使用锁保护共享状态
        state.anonymized_face_img = anonymized_face_img
        state.lost_r_img = lost_r_img
    output_queue.put((num, anonymized_face_img, 'anonymized'))
    output_queue.put((num, lost_r_img, 'lost'))

def recover_image(state, num, output_queue):
    with state.lock:
        anonymized_face_img = state.anonymized_face_img
        lost_r_img = state.lost_r_img
    if anonymized_face_img is None or lost_r_img is None:
        print("Cannot recover image: Anonymized or lost image is None.")
        return
    protected_face_rev_img = test_recovered(anonymized_face_img, lost_r_img, img_format='png')
    print(f"Recovered and saved successfully! Frame saved as '{num}.png'")
    output_queue.put((num, protected_face_rev_img, 'recovered'))

def display_images(output_queue, exit_event):
    global clear_display_flag
    plt.ion()
    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    anonymized_ax, recovered_ax = axes

    fig.canvas.manager.window.wm_geometry("+600+750")  # 移动图像窗口位置
    while not exit_event.is_set():  # 检查退出事件
        if clear_display_flag:  # Check if clear display is flagged
            anonymized_ax.clear()
            recovered_ax.clear()
            plt.draw()
            clear_display_flag = False  # Reset flag after clearing
            continue  # Skip further processing
        if not output_queue.empty():
            num, img, img_type = output_queue.get()
            img_np = img.cpu().numpy().squeeze().transpose(1, 2, 0)
            img_np = (img_np * 255).clip(0, 255).astype('uint8')
            if img_type == 'anonymized':
                anonymized_ax.clear()
                anonymized_ax.imshow(img_np)
                anonymized_ax.set_title(f'Anonymized Image {num}')
            elif img_type == 'recovered':
                recovered_ax.clear()
                recovered_ax.imshow(img_np)
                recovered_ax.set_title(f'Recovered Image {num}')

            plt.draw()
            plt.pause(0.001)

        if plt.waitforbuttonpress(0.1):
            break

        if exit_event.is_set():            # 额外检查退出事件
            plt.close(fig)  # 关闭图像窗口
            break
    plt.close(fig)  # 关闭图像窗口

def anonymize_and_recover_video(output_queue):
    global show_text_R_OK, start_time  # 声明使用全局变量
    out_original = cv2.VideoWriter('original.avi', cv2.VideoWriter_fourcc(*'XVID'), fps, (H, W))
    out_anonymized = cv2.VideoWriter('anonymized.avi', cv2.VideoWriter_fourcc(*'XVID'), fps, (H, W))
    out_recovered = cv2.VideoWriter('recovered.avi', cv2.VideoWriter_fourcc(*'XVID'), fps, (H, W))
    while not output_queue.empty():
        frame = output_queue.get()

        resized_RGB_frame = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), (H, W))
        protected_face = torch.tensor(resized_RGB_frame).permute(2, 0, 1).unsqueeze(0).clamp(0, 255).byte() / 255.0
        protected_face_np = protected_face.cpu().numpy().squeeze().transpose(1, 2, 0)  # 去掉第一个维度并恢复通道顺序
        protected_face_np = (protected_face_np * 255).clip(0, 255).astype('uint8')  # 2. 如果需要将值转换回 0-255 范围
        protected_face_frame_bgr = cv2.cvtColor(protected_face_np, cv2.COLOR_RGB2BGR)  # 3. 将颜色通道从 RGB 转回 BGR
        out_original.write(protected_face_frame_bgr)  # 仅在录制时写入视频文件

        protected_face_img, anonymized_face_img, lost_r_img  = test_anonymized(protected_face, img_format='png')
        anonymized_face_np = anonymized_face_img.cpu().numpy().squeeze().transpose(1, 2, 0)  # 去掉第一个维度并恢复通道顺序
        anonymized_face_np = (anonymized_face_np * 255).clip(0, 255).astype('uint8')    # 2. 如果需要将值转换回 0-255 范围
        anonymized_face_frame_bgr = cv2.cvtColor(anonymized_face_np, cv2.COLOR_RGB2BGR)  # 3. 将颜色通道从 RGB 转回 BGR
        out_anonymized.write(anonymized_face_frame_bgr)
        protected_face_rev_img = test_recovered(anonymized_face_img, lost_r_img, img_format='png')
        protected_face_rev_np = protected_face_rev_img.cpu().numpy().squeeze().transpose(1, 2, 0)  # 去掉第一个维度并恢复通道顺序
        protected_face_rev_np = (protected_face_rev_np * 255).clip(0, 255).astype('uint8')  # 2. 如果需要将值转换回 0-255 范围
        protected_face_rev_frame_bgr = cv2.cvtColor(protected_face_rev_np, cv2.COLOR_RGB2BGR)  # 3. 将颜色通道从 RGB 转回 BGR
        out_recovered.write(protected_face_rev_frame_bgr)

    out_original.release()
    out_anonymized.release()  # Release video writer after processing all frames
    out_recovered.release()
    print('Original video saved.')
    print('Anonymized video saved.')
    print('Recovered video saved.')
    start_time = time.time()
    show_text_R_OK = True

def start_recording(*args):
    global is_recording, show_text_K, show_text_A, show_text_R, show_text_R_OK, start_time, recording_frames
    start_time = time.time()  # 记录时间
    is_recording = not is_recording
    if is_recording:
        show_text_K = True
        show_text_A = False
        show_text_R = False
        show_text_R_OK = False
        print("Recording started")
    else:
        show_text_K = False
        show_text_A = False
        show_text_R = False
        print("Recording stopped")
        print(len(recording_frames))
        threading.Thread(target=anonymize_and_recover_video, args=(output_queue1,)).start()

def save_and_anonymize_frame(*args):
    global num, show_text_A, show_text_R, show_text_K, start_time
    start_time = time.time()  # 记录时间
    num += 1
    show_text_A = True
    show_text_R = False
    show_text_K = False
    threading.Thread(target=anonymiz_image, args=(frame, num, output_queue, state)).start()

def recover_frame(*args):
    global show_text_R, show_text_A, show_text_K, start_time
    start_time = time.time()  # 记录时间
    show_text_A = False
    show_text_R = True
    show_text_K = False
    threading.Thread(target=recover_image, args=(state, num, output_queue)).start()

def clear_display(*args):
    global clear_display_flag
    clear_display_flag = True
if __name__ == "__main__":
    cap = cv2.VideoCapture(0)# 打开默认摄像头
    if not cap.isOpened():
        print("Cannot open camera")
    else:
        print("Camera opened successfully")
    # cap.release()
    cv2.namedWindow('Camera', cv2.WINDOW_NORMAL)# 创建窗口并设置大小
    cv2.resizeWindow('Camera', H, W)
    # cv2.moveWindow('Camera', 600, 70)  # 将窗口移动到屏幕的左上角
    cv2.moveWindow('Camera', 750, 100)  # 将窗口移动到屏幕的左上角
    num = 0
    is_recording = False  # key_num 初始化录制状态  0 不录制   1录制 2处理
    output_queue = queue.Queue()
    output_queue1 = queue.Queue()
    exit_event = threading.Event()  # 创建退出事件
    state = SharedState()
    display_thread = threading.Thread(target=display_images, args=(output_queue, exit_event), daemon=True)
    display_thread.start()
    recording_frames = []
    show_text_K = False  # 标志变量
    show_text_A = False  # 标志变量
    show_text_R = False  # 标志变量
    interval = 1 / fps
    clear_display_flag=False
    cv2.createButton("Start/Stop Recording", start_recording)    # 创建按钮
    cv2.createButton("Save and Anonymize Image", save_and_anonymize_frame)
    cv2.createButton("Recover Image", recover_frame)
    cv2.createButton("Clear Display", clear_display)  # 添加清空显示的按钮

    last_time = time.time()
    while True:
        current_time = time.time()
        ret, frame = cap.read()
        if not ret:
            break

        # cv2.imshow('Camera', frame)    # 显示视频帧
        display_frame = frame.copy()

        if is_recording:
            if current_time - last_time >= interval:
                recording_frame = frame
                recording_frames.append(recording_frame)
                output_queue1.put(recording_frame)
                last_time = current_time
        if show_text_A:
            cv2.putText(display_frame, "Anonymizing", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            if time.time() - start_time >= 1.6:  show_text_A = False
        if show_text_R:
            cv2.putText(display_frame, "Recovering", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            if time.time() - start_time >= 0.4:  show_text_R = False
        if show_text_K:
            cv2.putText(display_frame, "Recording...", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        if show_text_R_OK:
            cv2.putText(display_frame, "Record completed", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            # if time.time() - start_time >= 3: show_text_R_OK = False

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):    # 按 'q' 键退出
            exit_event.set()  # 设置退出事件
            break
            # 等待显示线程结束
        cv2.imshow('Camera', display_frame)  # 显示视频帧
    display_thread.join()
    cap.release()# 释放摄像头和视频写入对象，并关闭窗口
    cv2.destroyAllWindows()




    video_paths = ['/home/WRL/WRL/RFA_exe/original.avi', '/home/WRL/WRL/RFA_exe/anonymized.avi',
                   '/home/WRL/WRL/RFA_exe/recovered.avi']
    caps = [cv2.VideoCapture(path) for path in video_paths]
    for i, cap in enumerate(caps):
        if not cap.isOpened():
            print(f"无法打开视频文件: {video_paths[i]}")
            exit()
    while True:
        frames = []
        for cap in caps:
            ret, frame = cap.read()
            if not ret:
                print("视频读取完毕或发生错误")
                break
            frames.append(frame)
        if len(frames) < 3:
            print("所有视频均已读取完毕")
            break
        combined_frame = np.hstack(frames)

        screen_height, screen_width = 1080, 1920  # 根据您的显示器分辨率调整
        height, width = combined_frame.shape[:2]
        # 创建黑色背景
        background = np.zeros((screen_height, screen_width, 3), dtype=np.uint8)
        x_offset = (screen_width - width) // 2
        y_offset = (screen_height - height) // 2
        background[y_offset:y_offset + height, x_offset:x_offset + width] = combined_frame

        cv2.imshow('Combined Video', background)
        # cv2.imshow('Combined Video', combined_frame)
        if cv2.waitKey(300) & 0xFF == ord('q'):        # 显示每帧的时间设置为300毫秒（0.3秒），可根据需要调整
            break
    for cap in caps:
        cap.release()

    cv2.destroyAllWindows()

# if key == ord('k'):  # 按 'k' 键开始/停止录制
#     start_time = time.time()  # 记录时间
#     is_recording = not is_recording
#     if is_recording:
#         show_text_K = True
#         show_text_A = False
#         show_text_R = False
#         show_text_R_OK = False
#         print("Recording started")
#     else:
#         show_text_K=False
#         show_text_A = False
#         show_text_R = False
#         print("Recording stopped")
#         print(len(recording_frames))
#         threading.Thread(target=anonymize_and_recover_video, args=(output_queue1,)).start()
# if key == ord('a'):# 按 's' 键保存当前帧为图片
#     start_time = time.time()  # 记录时间
#     num += 1
#     show_text_A=True
#     show_text_R = False
#     show_text_K = False
#     threading.Thread(target=anonymiz_image, args=(frame, num, output_queue, state)).start()
# elif key == ord('r'):
#     start_time = time.time()  # 记录时间
#     show_text_A = False
#     show_text_R = True
#     show_text_K = False
#     threading.Thread(target=recover_image, args=(state, num, output_queue)).start()