from train import train
train(lamda_guide=1, lamda_reconstruction=5, lamda_low_frequency=1, model_name='model_151', image_name='151.png')