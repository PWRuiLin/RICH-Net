# Super parameters
clamp = 2.0
channels_in = 3
log10_lr = -4.5   #4.5
lr = 10 ** log10_lr
epochs = 2000                                                                                                           #lamda 2000
weight_decay = 1e-5
init_scale = 0.01

lamda_guide = 1
lamda_Lssim = 0.3; lamda_Lchab = 0.65; lamda_Lgwl = 0.05#; lamda_mse=1
lamda_reconstruction = 3    #10
lamda_low_frequency = 1     #10
device_ids = [0]

# Train:
batch_size_train = 16         #16
cropsize_train = 128
betas = (0.5, 0.999)
weight_step = 500
gamma = 0.5

# ValID:
batchsize_valid = 2
shuffle_val = False
val_freq = 1
cropsize_valid_CelebAHQ = 128
cropsize_valid_CelebA = 128
cropsize_valid_LFW = 128
#TEST
batchsize_test = 2

# Dataset
Dataset_TRAIN_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_VALID_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_TEST_mode = 'CelebA-HQ'     # CelebA-HQ jpg/ CelebA jpg/ LFW jpg/ FFHQ png/ AGE_ADULTS / experiment1_8 experiment1_2 png/ experiment2 / experiment3 png
TRAIN_PATH_CelebAHQ = './Dataset/CelebA-HQ/train/'
VALID_PATH_CelebAHQ = './Dataset/CelebA-HQ/valid/'
TEST_PATH_CelebAHQ = './Dataset/CelebA-HQ/test/'

# Display and logging:
loss_display_cutoff = 2.0
loss_names = ['L', 'lr']
silent = False
live_visualization = False
progress_bar = False


# Saving checkpoints:
loss = 'MSE' # MAE MSE
MODEL_PATH = '/media/WRL/D/WRL/HiNet_Robust_main/other_method/GenRAN_main/RFHN/model/test_model/'

checkpoint_on_error = False
SAVE_freq = 1




# Load:
suffix = 'model_141_fmmrdb_best.pth'#model_checkpoint_00001.pt model_BEST

tain_next = False
trained_epoch = 0
