from train import train
train(lamda_guide=1, lamda_reconstruction=3, lamda_low_frequency=1, model_name='model_131', image_name='131.png')