from train import train_loss_DWT_No
train_loss_DWT_No(lamda_guide=1, lamda_reconstruction=4, lamda_low_frequency=1,
           model_name='model_DWTNo_No', image_name='DWTNo_No.png')
