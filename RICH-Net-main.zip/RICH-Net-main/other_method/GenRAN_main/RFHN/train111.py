from train import train
train(lamda_guide=1, lamda_reconstruction=1, lamda_low_frequency=1, model_name='model_111', image_name='111.png')