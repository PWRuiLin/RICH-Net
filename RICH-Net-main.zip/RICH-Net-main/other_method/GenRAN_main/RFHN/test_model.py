import math
import torch
import torch.nn
import torch.optim
import torchvision
import numpy as np
from models.model import *
import config as c
import datasets
import models.Unet_common as common
import pytorch_ssim
from calculate_PSNR_SSIM import  calculate_PSNR_SSIM
from calculate_APD_RMSE import  calculate_APD_RMSE_MAE
from models.noise import Noise
calculate_ssim = pytorch_ssim.SSIM(window_size=11)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def load(net, optim, name):
    state_dicts = torch.load(name)
    network_state_dict = {k:v for k,v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    try:
        optim.load_state_dict(state_dicts['opt'])
    except:
        print('Cannot load optimizer for some reason or other')
def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise
def calculate_psnr(img1, img2):
    # img1 and img2 have range [0, 255]

    # img1 = img1.astype(np.float64)
    # img2 = img2.astype(np.float64)
    # img1 = img1.numpy().astype(np.float64)
    # img2 = img2.numpy().astype(np.float64)
    img1 = img1.detach().cpu().numpy().astype(np.float64)
    img2 = img2.detach().cpu().numpy().astype(np.float64)
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    PIXEL_MAX = 1  # 1      RGB:255
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))
def test_model_noise(model = 'model_141_best.pth', img='jpg', noise = 'Gaussian({})', Noise_intensity=0.01):
    net = Model()
    net.cuda()
    init_model(net)
    net = torch.nn.DataParallel(net, device_ids=c.device_ids)
    params_trainable = (list(filter(lambda p: p.requires_grad, net.parameters())))
    optim = torch.optim.Adam(params_trainable, lr=c.lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)
    # load(c.MODEL_PATH + c.suffix +'_{}'.format(num)+'.pt')  #pth   pt
    # load(net, optim, c.MODEL_PATH + c.suffix + '_{}'.format(num) + '_best.pth')  # pth   pt
    load(net, optim, c.MODEL_PATH + model)  # pth   pt
    net.eval()
    noise_layers = [noise.format(Noise_intensity)].copy()
    Noises = Noise(noise_layers)
    dwt = common.DWT()
    iwt = common.IWT()
    with torch.no_grad():
        SSIM_AVE = 0; PSNR_AVE = 0; PSNR1 = 0; SSIM1 = 0
        print(len(datasets.testloader))
        for i_batch, data in enumerate(datasets.testloader):
            data = data.to(device)
            cover = data[::2]
            secret = data[1::2]
            cover_input = dwt(cover)
            secret_input = dwt(secret)
            input_img = torch.cat((cover_input, secret_input), 1)
            #################
            #    forward:   #
            #################
            output = net(input_img)
            output_steg = output.narrow(1, 0, 4 * c.channels_in)
            output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
            steg_img = iwt(output_steg)
            steg_img_noise = Noises(steg_img)
            steg_img_noise_dwt = dwt(steg_img_noise)
            backward_z = gauss_noise(output_z.shape)
            #################
            #   backward:   #
            #################
            output_rev = torch.cat((steg_img_noise_dwt, backward_z), 1)
            bacward_img = net(output_rev, rev=True)
            secret_rev = bacward_img.narrow(1, 4 * c.channels_in, bacward_img.shape[1] - 4 * c.channels_in)
            secret_rev = iwt(secret_rev)



            torchvision.utils.save_image(cover, c.IMAGE_TEST_PATH_cover + '%.d.' % i_batch + img) #png jpg
            torchvision.utils.save_image(secret, c.IMAGE_TEST_PATH_secret + '%.d.' % i_batch + img)
            torchvision.utils.save_image(steg_img_noise, c.IMAGE_TEST_PATH_steg + '%.d.' % i_batch + img)
            torchvision.utils.save_image(secret_rev, c.IMAGE_TEST_PATH_secret_rev + '%.d.' % i_batch + img)
        print('processed Ok')
def test_model(model = 'model_141_best.pth', img='jpg'):
    net = Model()
    net.cuda()
    init_model(net)
    net = torch.nn.DataParallel(net, device_ids=c.device_ids)
    params_trainable = (list(filter(lambda p: p.requires_grad, net.parameters())))
    optim = torch.optim.Adam(params_trainable, lr=c.lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)
    # load(c.MODEL_PATH + c.suffix +'_{}'.format(num)+'.pt')  #pth   pt
    # load(net, optim, c.MODEL_PATH + c.suffix + '_{}'.format(num) + '_best.pth')  # pth   pt
    load(net, optim, c.MODEL_PATH + model)  # pth   pt
    net.eval()
    dwt = common.DWT()
    iwt = common.IWT()
    with torch.no_grad():
        SSIM_AVE = 0; PSNR_AVE = 0; PSNR1 = 0; SSIM1 = 0
        print(len(datasets.testloader))
        for i_batch, data in enumerate(datasets.testloader):
            data = data.to(device)
            cover = data[::2]
            secret = data[1::2]
            cover_input = dwt(cover)
            secret_input = dwt(secret)
            input_img = torch.cat((cover_input, secret_input), 1)
            #################
            #    forward:   #
            #################
            output = net(input_img)
            output_steg = output.narrow(1, 0, 4 * c.channels_in)
            output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
            steg_img = iwt(output_steg)
            backward_z = gauss_noise(output_z.shape)
            lost_r = iwt(output_z)
            random_z = iwt(backward_z)
            # print('output=',output)
            # print('output_steg=',output_steg)
            # print('output_z=',output_z)
            # print('steg_img=',steg_img)
            #################
            #   backward:   #
            #################
            output_rev = torch.cat((output_steg, backward_z), 1)
            bacward_img = net(output_rev, rev=True)
            secret_rev = bacward_img.narrow(1, 4 * c.channels_in, bacward_img.shape[1] - 4 * c.channels_in)
            secret_rev = iwt(secret_rev)
            cover_rev = bacward_img.narrow(1, 0, 4 * c.channels_in)
            cover_rev = iwt(cover_rev)
            resi_cover = (steg_img - cover) * 20
            resi_secret = (secret_rev - secret) * 20
            # print(i_batch)
            # PSNR = calculate_psnr(secret_rev.to(device), secret.to(device))
            # PSNR1 = PSNR1 + PSNR
            # PSNR_AVE = PSNR1 / (i_batch + 1)
            # SSIM = calculate_ssim(secret_rev.to(device), secret.to(device))
            # SSIM1 = SSIM1 + SSIM
            # SSIM_AVE = SSIM1 / (i_batch + 1)


            torchvision.utils.save_image(cover, c.IMAGE_TEST_PATH_cover + '%.d.' % i_batch + img) #png jpg    '%.5d.' % i_batch
            torchvision.utils.save_image(secret, c.IMAGE_TEST_PATH_secret + '%.d.' % i_batch + img)
            torchvision.utils.save_image(steg_img, c.IMAGE_TEST_PATH_steg + '%.d.' % i_batch + img)
            torchvision.utils.save_image(secret_rev, c.IMAGE_TEST_PATH_secret_rev + '%.d.' % i_batch + img)
            torchvision.utils.save_image(resi_cover, c.IMAGE_TEST_PATH_resi_cover + '%.d.' % i_batch + img)
            torchvision.utils.save_image(resi_secret, c.IMAGE_TEST_PATH_resi_secret + '%.d.' % i_batch + img)
            torchvision.utils.save_image(lost_r, c.IMAGE_TEST_PATH_output_r + '%.d.' % i_batch + img)
            torchvision.utils.save_image(random_z, c.IMAGE_TEST_PATH_backward_z + '%.d.' % i_batch + img)

        print('processed Ok')
        PSNR_all = []; SSIM_all = []
        PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=False, secret=True, cover=False, img=img)
        print(f' secret | model={model} | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
        PSNR_all = []; SSIM_all=[]
        PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=False, secret=False, cover=True, img=img)
        print(f' cover | model={model} | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
        MAE_all = []; RMSE_all = []; MAE = []
        MAE_all, RMSE_all, MAE =calculate_APD_RMSE_MAE(test_Y=False, secret=True, cover=False, img=img)
        print(f' secret | model={model} | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
        MAE_all = []; RMSE_all = []; MAE = []
        MAE_all, RMSE_all, MAE = calculate_APD_RMSE_MAE(test_Y=False, secret=False, cover=True, img=img)
        print(f' cover | model={model} | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
            #Average: PSNR: 51.311638 dB, SSIM: 0.997715
def test_model_DWTNo(model = 'model_DWTNo_No_best.pth', img='jpg'):
    net = Model()
    net.cuda()
    init_model(net)
    net = torch.nn.DataParallel(net, device_ids=c.device_ids)
    params_trainable = (list(filter(lambda p: p.requires_grad, net.parameters())))
    optim = torch.optim.Adam(params_trainable, lr=c.lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)
    # load(c.MODEL_PATH + c.suffix +'_{}'.format(num)+'.pt')  #pth   pt
    # load(net, optim, c.MODEL_PATH + c.suffix + '_{}'.format(num) + '_best.pth')  # pth   pt
    load(net, optim, c.MODEL_PATH + model)  # pth   pt
    net.eval()

    dwt = common.DWT()
    iwt = common.IWT()
    with torch.no_grad():
        SSIM_AVE = 0; PSNR_AVE = 0; PSNR1 = 0; SSIM1 = 0
        print(len(datasets.testloader))
        for i_batch, data in enumerate(datasets.testloader):
            data = data.to(device)
            cover = data[::2]
            secret = data[1::2]
            cover_input = cover
            secret_input = secret
            input_img = torch.cat((cover_input, secret_input), 1)
            #################
            #    forward:   #
            #################
            output = net(input_img)
            output_steg = output.narrow(1, 0, c.channels_in)
            output_z = output.narrow(1, c.channels_in, output.shape[1] - c.channels_in)
            steg_img = output_steg
            backward_z = gauss_noise(output_z.shape)
            lost_r = output_z
            random_z = backward_z
            # print('output=',output)
            # print('output_steg=',output_steg)
            # print('output_z=',output_z)
            # print('steg_img=',steg_img)
            #################
            #   backward:   #
            #################
            output_rev = torch.cat((output_steg, backward_z), 1)
            bacward_img = net(output_rev, rev=True)
            secret_rev = bacward_img.narrow(1, c.channels_in, bacward_img.shape[1] - c.channels_in)
            cover_rev = bacward_img.narrow(1, 0, c.channels_in)
            cover_rev = cover_rev
            resi_cover = (steg_img - cover) * 20
            resi_secret = (secret_rev - secret) * 20
            # print(i)
            # PSNR = calculate_psnr(secret_rev.to(device), secret.to(device))
            # PSNR1 = PSNR1 + PSNR
            # PSNR_AVE = PSNR1 / (i + 1)
            # SSIM = calculate_ssim(secret_rev.to(device), secret.to(device))
            # SSIM1 = SSIM1 + SSIM
            # SSIM_AVE = SSIM1 / (i + 1)

            torchvision.utils.save_image(cover, c.IMAGE_TEST_PATH_cover + '%.d.' % i_batch + img) #png jpg
            torchvision.utils.save_image(secret, c.IMAGE_TEST_PATH_secret + '%.d.' % i_batch + img)
            torchvision.utils.save_image(steg_img, c.IMAGE_TEST_PATH_steg + '%.d.' % i_batch + img)
            torchvision.utils.save_image(secret_rev, c.IMAGE_TEST_PATH_secret_rev + '%.d.' % i_batch + img)
            torchvision.utils.save_image(resi_cover, c.IMAGE_TEST_PATH_resi_cover + '%.d.' % i_batch + img)
            torchvision.utils.save_image(resi_secret, c.IMAGE_TEST_PATH_resi_secret + '%.d.' % i_batch + img)
            torchvision.utils.save_image(lost_r, c.IMAGE_TEST_PATH_output_r + '%.d.' % i_batch + img)
            torchvision.utils.save_image(random_z, c.IMAGE_TEST_PATH_backward_z + '%.d.' % i_batch + img)
        print('processed Ok')
        PSNR_all = []; SSIM_all = []
        PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=False, secret=True, cover=False, img=img)
        print(f' secret | model={model} | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
        PSNR_all = []; SSIM_all=[]
        PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=False, secret=False, cover=True, img=img)
        print(f' cover | model={model} | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
        MAE_all = []; RMSE_all = []; MAE = []
        MAE_all, RMSE_all, MAE =calculate_APD_RMSE_MAE(test_Y=False, secret=True, cover=False, img=img)
        print(f' secret | model={model} | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
        MAE_all = []; RMSE_all = []; MAE = []
        MAE_all, RMSE_all, MAE = calculate_APD_RMSE_MAE(test_Y=False, secret=False, cover=True, img=img)
        print(f' cover | model={model} | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
            #Average: PSNR: 51.311638 dB, SSIM: 0.997715
# test_model_DWTNo(model = 'model_DWTNo_No_8_128_128_best.pth', img='jpg')
test_model(model = 'model_best.pth', img='jpg')
#model_141_best.pth model_141.pt
#model_DWTNo_No_best
#model_DWTYes_No_best
#model_DWTYes_MAE_best
#model_DWTYes_MSE_best              =model_141_best
# test_model_noise(model = 'model_DWTYes_MSE_best.pth', img='jpg', noise = 'Gaussian_noise({})', Noise_intensity=0.03)
#'Gaussian_noise({})'
#'Jpeg_compression({})'
#'Gaussian_blur({})'


#model_DWTYes_SmoothMAE_best.pth
#model_DWTYes_SmoothMSE_best
#model_DWTYes_SmoothMSE0.1_best
#model_DWTYes_SmoothMSE0.05_best.pth
#model_DWTYes_SmoothMSE0.01_best.pth


#1024*1024
# model141   CelebA-HQ
# secret | model=model_141_best.pth | PSNR_AVE=58.26910887511729 | SSIM_AVE=0.9995650637010209
# cover | model = model_141_best.pth | PSNR_AVE = 49.24029280606647 | SSIM_AVE = 0.99448154697287
# secret | model = model_141_best.pth | MAE_AVE = 0.06350480715433757 | RMSE_AVE = 0.34661462533214005
# cover | model = model_141_best.pth | MAE_AVE = 0.46364166895548514 | RMSE_AVE = 0.8912009666424799
# model141   CelebA jpg
# secret | model = model_141_best.pth | PSNR_AVE = 51.46447439914846 | SSIM_AVE = 0.996710222824222
# cover | model = model_141_best.pth | PSNR_AVE = 51.43304057391013 | SSIM_AVE = 0.996349727897121
# secret | model = model_141_best.pth | MAE_AVE = 0.30267551422119154 | RMSE_AVE = 0.6878228646565036
# cover | model = model_141_best.pth | MAE_AVE = 0.3034366226196289 | RMSE_AVE = 0.6890934304391328
# model141   LFW jpg
# secret | model = model_141_best.pth | PSNR_AVE = 51.219160742852324 | SSIM_AVE = 0.996420288234377
# cover | model = model_141_best.pth | PSNR_AVE = 51.126967055432196 | SSIM_AVE = 0.9960526478821867
# secret | model = model_141_best.pth | MAE_AVE = 0.31504856745402027 | RMSE_AVE = 0.7064651718884853
# cover | model = model_141_best.pth | MAE_AVE = 0.3179338455200196 | RMSE_AVE = 0.7128517803873337

