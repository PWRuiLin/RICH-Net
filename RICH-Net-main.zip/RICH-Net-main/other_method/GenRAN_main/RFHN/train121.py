from train import train
train(lamda_guide=1, lamda_reconstruction=2, lamda_low_frequency=1, model_name='model_121', image_name='121.png')