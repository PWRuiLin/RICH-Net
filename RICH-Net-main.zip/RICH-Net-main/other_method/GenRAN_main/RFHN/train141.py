from train import train
train(lamda_guide=1, lamda_reconstruction=4, lamda_low_frequency=1, model_name='model_141', image_name='141.png')