import torch
import torch.nn
import torch.optim
import math
import numpy as np
from models.model import *
import torchvision
import config as c
from tensorboardX import SummaryWriter
import datasets
import viz
import models.Unet_common as common
from models.loss import gauss_noise, guide_loss, reconstruction_loss, \
    low_frequency_loss, L1_Charbonnier_loss, GWLoss, ssim_loss, low_frequency_loss_MAE, low_frequency_loss_SmoothMAE, \
    low_frequency_loss_MSE, low_frequency_loss_SmoothMSE
import warnings
import os
import time
from tqdm import tqdm
warnings.filterwarnings("ignore")
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'# 设置 CUDA_LAUNCH_BLOCKING 环境变量为 1

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# 在训练过程中适时调用 empty_cache() 来清空 GPU 缓存
torch.cuda.empty_cache()

# 网络参数数量
def get_parameter_number(net):
    total_num = sum(p.numel() for p in net.parameters())
    trainable_num = sum(p.numel() for p in net.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}
def computePSNR(origin,pred):
    origin = np.array(origin)
    origin = origin.astype(np.float32)
    pred = np.array(pred)
    pred = pred.astype(np.float32)
    mse = np.mean((origin/1.0 - pred/1.0) ** 2 )
    if mse < 1.0e-10:
      return 100
    return 10 * math.log10(255.0**2/mse)
def load(name):
    state_dicts = torch.load(name)
    network_state_dict = {k: v for k, v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    try:
        optim.load_state_dict(state_dicts['opt'])
    except:
        print('Cannot load optimizer for some reason or other')

#####################
# Model initialize: #
#####################
net = Model()# Model:DWT           Model1:DWT_No
net.cuda()
init_model(net)
net = torch.nn.DataParallel(net, device_ids=c.device_ids)
para = get_parameter_number(net)
params_trainable = (list(filter(lambda p: p.requires_grad, net.parameters())))

optim = torch.optim.Adam(params_trainable, lr=c.lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)

dwt = common.DWT()
iwt = common.IWT()
ssim_loss = ssim_loss
charbonnier_loss = L1_Charbonnier_loss()
gwl_oss = GWLoss()

def Lf_loss(steg_low, cover_low, low_frequency_loss='No'):
    if low_frequency_loss == 'No':
        l_loss = 0
    if low_frequency_loss == 'MAE':
        l_loss = low_frequency_loss_MAE(steg_low, cover_low)
    if low_frequency_loss == 'SmoothMAE':
        l_loss = low_frequency_loss_SmoothMAE(steg_low, cover_low)
    if low_frequency_loss == 'SmoothMSE':
        l_loss = low_frequency_loss_SmoothMSE(steg_low, cover_low)
    if low_frequency_loss == 'MSE':
        l_loss = low_frequency_loss_MSE(steg_low, cover_low)
    if low_frequency_loss == 'Charbonnier':
        l_loss = charbonnier_loss(steg_low, cover_low)
    return l_loss
if c.tain_next:
    load(c.MODEL_PATH + c.suffix)
def train(lamda_guide=1, lamda_reconstruction=1, lamda_low_frequency=1, model_name='model_111', image_name='111.png'):
    try:
        start = time.time()
        writer = SummaryWriter(comment='hinet', filename_suffix="steg")
        train_loss_best = 666666666666666666
        for i_epoch in range(c.epochs):
            start_i_epoch = time.time()
            i_epoch = i_epoch + c.trained_epoch + 1
            loss_history = []
            #     train:    #
            # for i_batch, (fake, real) in enumerate(zip(datasets.trainloaderfake, datasets.trainloaderreal), start=0):
            for i_batch, data in enumerate(datasets.trainloader):
                data = data.to(device)
                cover = data[::2]
                secret = data[1::2]
                cover_input = dwt(cover)
                secret_input = dwt(secret)

                input_img = torch.cat((cover_input, secret_input), 1)
                #    forward:   #
                output = net(input_img)
                output_steg = output.narrow(1, 0, 4 * c.channels_in)
                output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                steg_img = iwt(output_steg)
                #   backward:   #
                output_z_guass = gauss_noise(output_z.shape)
                output_rev = torch.cat((output_steg, output_z_guass), 1)
                output_image = net(output_rev, rev=True)
                secret_rev = output_image.narrow(1, 4 * c.channels_in, output_image.shape[1] - 4 * c.channels_in)
                secret_rev = iwt(secret_rev)
                #     loss:     #
                g_loss = guide_loss(steg_img.cuda(), cover.cuda())
                r_loss = reconstruction_loss(secret_rev, secret)
                steg_low = output_steg.narrow(1, 0, c.channels_in)
                cover_low = cover_input.narrow(1, 0, c.channels_in)
                l_loss = low_frequency_loss(steg_low, cover_low)
                total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                if total_loss < train_loss_best:
                    train_loss_best = total_loss
                    torch.save({'opt': optim.state_dict(),
                                'net': net.state_dict()}, c.MODEL_PATH + model_name + '_best.pth')
                    torchvision.utils.save_image(cover, c.IMAGE_TRAIN_PATH_cover + image_name)
                    torchvision.utils.save_image(secret, c.IMAGE_TRAIN_PATH_secret + image_name)
                    torchvision.utils.save_image(steg_img, c.IMAGE_TRAIN_PATH_steg + image_name)
                    torchvision.utils.save_image(secret_rev, c.IMAGE_TRAIN_PATH_secret_rev + image_name)

                total_loss.backward()
                optim.step()
                optim.zero_grad()

                loss_history.append([total_loss.item(), 0.])
            epoch_losses = np.mean(np.array(loss_history), axis=0)
            epoch_losses[1] = np.log10(optim.param_groups[0]['lr'])
            end_i_epoch = time.time()
            print('T_i_epoch = ' ,end_i_epoch - start_i_epoch)
            #     val:    #
            if i_epoch % c.val_freq == 0:
                with torch.no_grad():
                    psnr_s = []
                    psnr_c = []
                    net.eval()
                    # for i, (fake, real) in enumerate(zip(datasets.validloaderfake, datasets.validloaderreal), start=0):
                    #     cover = fake.to(device)
                    #     secret = real.to(device)
                    for i_batch, data in enumerate(datasets.trainloader):
                        data = data.to(device)
                        cover = data[::2]
                        secret = data[1::2]
                        cover_input = dwt(cover)
                        secret_input = dwt(secret)

                        input_img = torch.cat((cover_input, secret_input), 1)
                        #    forward:   #
                        output = net(input_img)
                        output_steg = output.narrow(1, 0, 4 * c.channels_in)
                        steg = iwt(output_steg)
                        output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                        output_z = gauss_noise(output_z.shape)

                        #   backward:   #
                        output_steg = output_steg.cuda()
                        output_rev = torch.cat((output_steg, output_z), 1)
                        output_image = net(output_rev, rev=True)
                        secret_rev = output_image.narrow(1, 4 * c.channels_in, output_image.shape[1] - 4 * c.channels_in)
                        secret_rev = iwt(secret_rev)

                        secret_rev = secret_rev.cpu().numpy().squeeze() * 255
                        np.clip(secret_rev, 0, 255)
                        secret = secret.cpu().numpy().squeeze() * 255
                        np.clip(secret, 0, 255)
                        cover = cover.cpu().numpy().squeeze() * 255
                        np.clip(cover, 0, 255)
                        steg = steg.cpu().numpy().squeeze() * 255
                        np.clip(steg, 0, 255)
                        psnr_temp = computePSNR(secret_rev, secret)
                        psnr_s.append(psnr_temp)
                        psnr_temp_c = computePSNR(cover, steg)
                        psnr_c.append(psnr_temp_c)

                    print(f' psnr = {np.mean(psnr_s)}')
                    writer.add_scalars("PSNR_S", {"average psnr": np.mean(psnr_s)}, i_epoch)
                    writer.add_scalars("PSNR_C", {"average psnr": np.mean(psnr_c)}, i_epoch)
            viz.show_loss(epoch_losses)
            writer.add_scalars("Train", {"Train_Loss": epoch_losses[0]}, i_epoch)
            weight_scheduler.step()

            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + model_name + '.pt')
        writer.close()
        end = time.time()                                                                                                   #结束记录代码运行时间
        print("T = ",round(end-start))
    except:
        if c.checkpoint_on_error:
            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + 'model_ABORT' + '.pt')
        raise
    finally:
        viz.signal_stop()

def train_loss(lamda_guide=1, lamda_reconstruction=1, lamda_low_frequency=1, DWT='YES', low_frequency_loss='No',
               model_name='model_111', image_name='111.png'):
    try:
        start = time.time()
        writer = SummaryWriter(comment='hinet', filename_suffix="steg")
        train_loss_best = 666666666666
        for i_epoch in range(c.epochs):
            start_i_epoch = time.time()
            i_epoch = i_epoch + c.trained_epoch + 1
            loss_history = []
            #     train:    #
            # for i_batch, (fake, real) in enumerate(zip(datasets.trainloaderfake, datasets.trainloaderreal), start=0):
            for i_batch, data in enumerate(datasets.trainloader):
                data = data.to(device)
                cover = data[::2]
                secret = data[1::2]
                if DWT == 'Yes':
                    # print('DWT == Yes')
                    cover_input = dwt(cover)
                    secret_input = dwt(secret)
                    # print(cover_input.shape)
                if DWT == 'No':
                    # print('DWT == No')
                    cover_input = cover
                    secret_input = secret
                    # print(cover_input.shape)
                input_img = torch.cat((cover_input, secret_input), 1)
                #    forward:   #
                output = net(input_img)
                output_steg = output.narrow(1, 0, 4 * c.channels_in)
                output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                steg_img = iwt(output_steg)
                #   backward:   #
                output_z_guass = gauss_noise(output_z.shape)
                output_rev = torch.cat((output_steg, output_z_guass), 1)
                output_image = net(output_rev, rev=True)
                secret_rev = output_image.narrow(1, 4 * c.channels_in, output_image.shape[1] - 4 * c.channels_in)
                secret_rev = iwt(secret_rev)
                #     loss:     #
                g_loss = guide_loss(steg_img.cuda(), cover.cuda())
                r_loss = reconstruction_loss(secret_rev, secret)
                steg_low = output_steg.narrow(1, 0, c.channels_in)
                cover_low = cover_input.narrow(1, 0, c.channels_in)
                # if low_frequency_loss == 'No':
                #     # print('low_frequency_loss == No')
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss
                # if low_frequency_loss == 'MAE':
                #     # print('low_frequency_loss == MAE')
                #     l_loss = low_frequency_loss_MAE(steg_low, cover_low)
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                # if low_frequency_loss == 'SmoothMAE':
                #     # print('low_frequency_loss == MSE')
                #     l_loss = low_frequency_loss_SmoothMAE(steg_low, cover_low)
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                # if low_frequency_loss == 'SmoothMSE':
                #     # print('low_frequency_loss == MSE')
                #     l_loss = low_frequency_loss_SmoothMSE(steg_low, cover_low)
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                # if low_frequency_loss == 'MSE':
                #     # print('low_frequency_loss == MSE')
                #     l_loss = low_frequency_loss_MSE(steg_low, cover_low)
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                # if low_frequency_loss == 'Charbonnier':
                #     # print('low_frequency_loss == RMSE')
                #     l_loss = charbonnier_loss(steg_low, cover_low)
                #     total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                l_loss = Lf_loss(steg_low, cover_low, low_frequency_loss=low_frequency_loss)
                total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss + lamda_low_frequency * l_loss
                if total_loss < train_loss_best:
                    train_loss_best = total_loss
                    torch.save({'opt': optim.state_dict(),
                                'net': net.state_dict()}, c.MODEL_PATH + model_name + '_best.pth')
                    torchvision.utils.save_image(cover, c.IMAGE_TRAIN_PATH_cover + image_name)
                    torchvision.utils.save_image(secret, c.IMAGE_TRAIN_PATH_secret + image_name)
                    torchvision.utils.save_image(steg_img, c.IMAGE_TRAIN_PATH_steg + image_name)
                    torchvision.utils.save_image(secret_rev, c.IMAGE_TRAIN_PATH_secret_rev + image_name)

                total_loss.backward()
                optim.step()
                optim.zero_grad()

                loss_history.append([total_loss.item(), 0.])
            epoch_losses = np.mean(np.array(loss_history), axis=0)
            epoch_losses[1] = np.log10(optim.param_groups[0]['lr'])
            end_i_epoch = time.time()
            print('T_i_epoch = ' ,end_i_epoch - start_i_epoch)
            #     val:    #
            if i_epoch % c.val_freq == 0:
                with torch.no_grad():
                    psnr_s = []
                    psnr_c = []
                    net.eval()
                    # for i, (fake, real) in enumerate(zip(datasets.validloaderfake, datasets.validloaderreal), start=0):
                    #     cover = fake.to(device)
                    #     secret = real.to(device)
                    for i_batch, data in enumerate(datasets.trainloader):
                        data = data.to(device)
                        cover = data[::2]
                        secret = data[1::2]
                        cover_input = dwt(cover)
                        secret_input = dwt(secret)

                        input_img = torch.cat((cover_input, secret_input), 1)
                        #    forward:   #
                        output = net(input_img)
                        output_steg = output.narrow(1, 0, 4 * c.channels_in)
                        steg = iwt(output_steg)
                        output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                        output_z = gauss_noise(output_z.shape)

                        #   backward:   #
                        output_steg = output_steg.cuda()
                        output_rev = torch.cat((output_steg, output_z), 1)
                        output_image = net(output_rev, rev=True)
                        secret_rev = output_image.narrow(1, 4 * c.channels_in, output_image.shape[1] - 4 * c.channels_in)
                        secret_rev = iwt(secret_rev)

                        secret_rev = secret_rev.cpu().numpy().squeeze() * 255
                        np.clip(secret_rev, 0, 255)
                        secret = secret.cpu().numpy().squeeze() * 255
                        np.clip(secret, 0, 255)
                        cover = cover.cpu().numpy().squeeze() * 255
                        np.clip(cover, 0, 255)
                        steg = steg.cpu().numpy().squeeze() * 255
                        np.clip(steg, 0, 255)
                        psnr_temp = computePSNR(secret_rev, secret)
                        psnr_s.append(psnr_temp)
                        psnr_temp_c = computePSNR(cover, steg)
                        psnr_c.append(psnr_temp_c)

                    print(f' psnr = {np.mean(psnr_s)}')
                    writer.add_scalars("PSNR_S", {"average psnr": np.mean(psnr_s)}, i_epoch)
                    writer.add_scalars("PSNR_C", {"average psnr": np.mean(psnr_c)}, i_epoch)
            viz.show_loss(epoch_losses)
            writer.add_scalars("Train", {"Train_Loss": epoch_losses[0]}, i_epoch)
            weight_scheduler.step()

            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + model_name + '.pt')
        writer.close()
        end = time.time()                                                                                                   #结束记录代码运行时间
        print("T = ",round(end-start))
    except:
        if c.checkpoint_on_error:
            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + 'model_ABORT' + '.pt')
        raise
    finally:
        viz.signal_stop()
def train_loss_DWT_No(lamda_guide=1, lamda_reconstruction=1, lamda_low_frequency=1, model_name='model_111', image_name='111.png'):
    try:
        start = time.time()
        writer = SummaryWriter(comment='hinet', filename_suffix="steg")
        train_loss_best = 666666666666
        for i_epoch in range(c.epochs):
            start_i_epoch = time.time()
            i_epoch = i_epoch + c.trained_epoch + 1
            loss_history = []
            #     train:    #
            # for i_batch, (fake, real) in enumerate(zip(datasets.trainloaderfake, datasets.trainloaderreal), start=0):
            for i_batch, data in enumerate(datasets.trainloader):
                data = data.to(device)
                cover = data[::2]
                secret = data[1::2]
                cover_input = cover
                secret_input = secret
                input_img = torch.cat((cover_input, secret_input), 1)
                #    forward:   #
                output = net(input_img)
                output_steg = output.narrow(1, 0, c.channels_in)
                output_z = output.narrow(1, c.channels_in, output.shape[1] - c.channels_in)
                steg_img = output_steg
                #   backward:   #
                output_z_guass = gauss_noise(output_z.shape)
                output_rev = torch.cat((output_steg, output_z_guass), 1)
                output_image = net(output_rev, rev=True)
                secret_rev = output_image.narrow(1, c.channels_in, output_image.shape[1] - c.channels_in)
                secret_rev = secret_rev
                #     loss:     #
                g_loss = guide_loss(steg_img.cuda(), cover.cuda())
                r_loss = reconstruction_loss(secret_rev, secret)
                total_loss = lamda_guide * g_loss + lamda_reconstruction * r_loss
                if total_loss < train_loss_best:
                    train_loss_best = total_loss
                    torch.save({'opt': optim.state_dict(),
                                'net': net.state_dict()}, c.MODEL_PATH + model_name + '_best.pth')
                    torchvision.utils.save_image(cover, c.IMAGE_TRAIN_PATH_cover + image_name)
                    torchvision.utils.save_image(secret, c.IMAGE_TRAIN_PATH_secret + image_name)
                    torchvision.utils.save_image(steg_img, c.IMAGE_TRAIN_PATH_steg + image_name)
                    torchvision.utils.save_image(secret_rev, c.IMAGE_TRAIN_PATH_secret_rev + image_name)

                total_loss.backward()
                optim.step()
                optim.zero_grad()

                loss_history.append([total_loss.item(), 0.])
            epoch_losses = np.mean(np.array(loss_history), axis=0)
            epoch_losses[1] = np.log10(optim.param_groups[0]['lr'])
            end_i_epoch = time.time()
            print('T_i_epoch = ' ,end_i_epoch - start_i_epoch)
            #     val:    #
            if i_epoch % c.val_freq == 0:
                with torch.no_grad():
                    psnr_s = []
                    psnr_c = []
                    net.eval()
                    # for i, (fake, real) in enumerate(zip(datasets.validloaderfake, datasets.validloaderreal), start=0):
                    #     cover = fake.to(device)
                    #     secret = real.to(device)
                    for i_batch, data in enumerate(datasets.trainloader):
                        data = data.to(device)
                        cover = data[::2]
                        secret = data[1::2]
                        cover_input = cover
                        secret_input = secret

                        input_img = torch.cat((cover_input, secret_input), 1)
                        #    forward:   #
                        output = net(input_img)
                        output_steg = output.narrow(1, 0, c.channels_in)
                        steg = output_steg
                        output_z = output.narrow(1, c.channels_in, output.shape[1] - c.channels_in)
                        output_z = gauss_noise(output_z.shape)

                        #   backward:   #
                        output_steg = output_steg.cuda()
                        output_rev = torch.cat((output_steg, output_z), 1)
                        output_image = net(output_rev, rev=True)
                        secret_rev = output_image.narrow(1, c.channels_in, output_image.shape[1] - c.channels_in)
                        secret_rev = secret_rev

                        secret_rev = secret_rev.cpu().numpy().squeeze() * 255
                        np.clip(secret_rev, 0, 255)
                        secret = secret.cpu().numpy().squeeze() * 255
                        np.clip(secret, 0, 255)
                        cover = cover.cpu().numpy().squeeze() * 255
                        np.clip(cover, 0, 255)
                        steg = steg.cpu().numpy().squeeze() * 255
                        np.clip(steg, 0, 255)
                        psnr_temp = computePSNR(secret_rev, secret)
                        psnr_s.append(psnr_temp)
                        psnr_temp_c = computePSNR(cover, steg)
                        psnr_c.append(psnr_temp_c)

                    print(f' psnr = {np.mean(psnr_s)}')
                    writer.add_scalars("PSNR_S", {"average psnr": np.mean(psnr_s)}, i_epoch)
                    writer.add_scalars("PSNR_C", {"average psnr": np.mean(psnr_c)}, i_epoch)
            viz.show_loss(epoch_losses)
            writer.add_scalars("Train", {"Train_Loss": epoch_losses[0]}, i_epoch)
            weight_scheduler.step()

            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + model_name + '.pt')
        writer.close()
        end = time.time()                                                                                                   #结束记录代码运行时间
        print("T = ",round(end-start))
    except:
        if c.checkpoint_on_error:
            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + 'model_ABORT' + '.pt')
        raise
    finally:
        viz.signal_stop()
def train_old():
    try:
        start = time.time()
        writer = SummaryWriter(comment='hinet', filename_suffix="steg")
        train_loss_best = 666666666666
        for i_epoch in range(c.epochs):
            start_i_epoch = time.time()
            i_epoch = i_epoch + c.trained_epoch + 1
            loss_history = []
            #     train:    #
            for i_batch, (fake, real) in enumerate(zip(datasets.trainloaderfake, datasets.trainloaderreal), start=0):
                cover = fake.to(device)
                secret = real.to(device)
                cover_input = dwt(cover)
                secret_input = dwt(secret)
                #    forward:   #
                input_img = torch.cat((cover_input, secret_input), 1)
                output = net(input_img)
                output_steg = output.narrow(1, 0, 4 * c.channels_in)
                output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                steg_img = iwt(output_steg)
                #   backward:   #
                output_z_guass = gauss_noise(output_z.shape)
                output_rev = torch.cat((output_steg, output_z_guass), 1)
                output_image = net(output_rev, rev=True)
                secret_rev = output_image.narrow(1, 4 * c.channels_in, output_image.shape[1] - 4 * c.channels_in)
                secret_rev = iwt(secret_rev)

                # stego_Yl,stego_Yh,cover_Yl,cover_Yh,stego_color,cover_color,stego_YH,cover_YH=ycbcr_images(secret,secret_rev)
                #     loss:     #
                g_loss = guide_loss(steg_img.cuda(), cover.cuda())  ##########
                # loss_ssim = 1 - ssim_loss(secret_rev.to(device), secret.to(device))
                # loss_chab = charbonnier_loss(secret_rev.to(device), secret.to(device))
                # loss_gwl = gwl_oss(secret_rev.to(device), secret.to(device))
                # mse_loss = MSE_loss(secret_rev, secret)
                # r_loss = c.lamda_Lssim * loss_ssim + c.lamda_Lchab * loss_chab + c.lamda_Lgwl * loss_gwl #+ c.lamda_mse * mse_loss
                r_loss = reconstruction_loss(secret_rev, secret)
                steg_low = output_steg.narrow(1, 0, c.channels_in)  ######
                cover_low = cover_input.narrow(1, 0, c.channels_in)  #####
                l_loss = low_frequency_loss(steg_low, cover_low)  ##########

                total_loss = c.lamda_guide * g_loss + c.lamda_reconstruction * r_loss + c.lamda_low_frequency * l_loss
                optim.zero_grad()
                total_loss.backward()
                optim.step()
                if total_loss < train_loss_best:
                    train_loss_best = total_loss
                    torch.save({'opt': optim.state_dict(),
                                'net': net.state_dict()}, c.MODEL_PATH + 'model_epoch_0.pth')
                    torchvision.utils.save_image(cover, c.IMAGE_TRAIN_PATH_cover + '0000.png')
                    torchvision.utils.save_image(secret, c.IMAGE_TRAIN_PATH_secret + '0000.png')
                    torchvision.utils.save_image(steg_img, c.IMAGE_TRAIN_PATH_steg + '0000.png')
                    torchvision.utils.save_image(secret_rev, c.IMAGE_TRAIN_PATH_secret_rev + '0000.png')
                loss_history.append([total_loss.item(), 0.])

            epoch_losses = np.mean(np.array(loss_history), axis=0)
            epoch_losses[1] = np.log10(optim.param_groups[0]['lr'])
            end_i_epoch = time.time()
            # print('T_i_epoch = ' ,end_i_epoch - start_i_epoch)
            #     val:    #
            if i_epoch % c.val_freq == 0:
                with torch.no_grad():
                    psnr_s = []
                    psnr_c = []
                    net.eval()
                    for (fake, real) in enumerate(zip(datasets.validloaderfake, datasets.validloaderreal), start=0):
                        cover = fake.to(device)
                        secret = real.to(device)
                        cover_input = dwt(cover)
                        secret_input = dwt(secret)

                        input_img = torch.cat((cover_input, secret_input), 1)
                        #    forward:   #
                        output = net(input_img)
                        output_steg = output.narrow(1, 0, 4 * c.channels_in)
                        steg = iwt(output_steg)
                        output_z = output.narrow(1, 4 * c.channels_in, output.shape[1] - 4 * c.channels_in)
                        output_z = gauss_noise(output_z.shape)
                        #   backward:   #
                        output_steg = output_steg.cuda()
                        output_rev = torch.cat((output_steg, output_z), 1)
                        output_image = net(output_rev, rev=True)
                        secret_rev = output_image.narrow(1, 4 * c.channels_in,
                                                         output_image.shape[1] - 4 * c.channels_in)
                        secret_rev = iwt(secret_rev)

                        secret_rev = secret_rev.cpu().numpy().squeeze() * 255
                        np.clip(secret_rev, 0, 255)
                        secret = secret.cpu().numpy().squeeze() * 255
                        np.clip(secret, 0, 255)
                        cover = cover.cpu().numpy().squeeze() * 255
                        np.clip(cover, 0, 255)
                        steg = steg.cpu().numpy().squeeze() * 255
                        np.clip(steg, 0, 255)
                        psnr_temp = computePSNR(secret_rev, secret)
                        psnr_s.append(psnr_temp)
                        psnr_temp_c = computePSNR(cover, steg)
                        psnr_c.append(psnr_temp_c)
                    print(f' psnr = {np.mean(psnr_s)}')
                    writer.add_scalars("PSNR_S", {"average psnr": np.mean(psnr_s)}, i_epoch)
                    writer.add_scalars("PSNR_C", {"average psnr": np.mean(psnr_c)}, i_epoch)
            viz.show_loss(epoch_losses)
            writer.add_scalars("Train", {"Train_Loss": epoch_losses[0]}, i_epoch)
            weight_scheduler.step()

        torch.save({'opt': optim.state_dict(),
                    'net': net.state_dict()}, c.MODEL_PATH + 'model' + '.pt')
        writer.close()
        end = time.time()  # 结束记录代码运行时间
        print("T = ", round(end - start))


    except:
        if c.checkpoint_on_error:
            torch.save({'opt': optim.state_dict(),
                        'net': net.state_dict()}, c.MODEL_PATH + 'model_ABORT' + '.pt')
        raise

    finally:
        viz.signal_stop()