from train import train_loss
train_loss(lamda_guide=1, lamda_reconstruction=4, lamda_low_frequency=1, DWT='Yes', low_frequency_loss = 'No',
           model_name='model_DWTYes_No', image_name='DWTYes_No.png')

