import glob
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
import config as c
from natsort import natsorted
import os
import cv2
def to_rgb(image):
    rgb_image = Image.new("RGB", image.size)
    rgb_image.paste(image)
    return rgb_image

class RFA_Net_Dataset(Dataset):
    def __init__(self, transforms_=None, mode="train"):
        self.transform = transforms_
        self.mode = mode
        if self.mode == "train":
            # TRAIN SETTING
            if c.Dataset_TRAIN_mode == 'CelebA-HQ':
                self.TRAIN_PATH = c.TRAIN_PATH_CelebAHQ
                self.format_train = 'jpg'
                # print('TRAIN DATASET is CelebA-HQ')

            # train
            self.files = natsorted(sorted(glob.glob(self.TRAIN_PATH + "/*." + self.format_train)))
        if self.mode == "valid":
            # VAL SETTING
            if c.Dataset_VALID_mode == 'CelebA-HQ':
                self.VALID_PATH = c.VALID_PATH_CelebAHQ
                self.format_valid = 'jpg'
                # print('VALID DATASET is CelebA-HQ')


            # valid
            self.files = natsorted(sorted(glob.glob(self.VALID_PATH + "/*." + self.format_valid)))
        if self.mode == "test":
            # TEST SETTING
            if c.Dataset_TEST_mode == 'CelebA-HQ':
                self.TEST_PATH = c.TEST_PATH_CelebAHQ
                self.format_test = 'jpg'
                # print('TEST DATASET is CelebA-HQ')
            if c.Dataset_TEST_mode == 'Other':
                self.TEST_PATH = c.TEST_PATH_Other
                print(self.TEST_PATH)
                self.format_test = 'png'
                print('TEST DATASET is Other')

            # valid
            self.files = natsorted(sorted(glob.glob(self.TEST_PATH + "/*." + self.format_test)))
    def __getitem__(self, index):
        try:
                image = Image.open(self.files[index])
                image = to_rgb(image)
                item = self.transform(image)
                return item
        except:
            return self.__getitem__(index + 1)
    def __len__(self):
        return len(self.files)

transform = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomVerticalFlip(),
    T.RandomCrop(c.cropsize_train),
    T.ToTensor()
])

transform_valid = T.Compose([
    # T.CenterCrop(cropsize_valid),
    T.Resize((c.resize_test,c.resize_test)),
    T.ToTensor(),
])

transform_test = T.Compose([
    # T.CenterCrop(c.cropsize_test),
    T.Resize((c.resize_test,c.resize_test)),
    T.ToTensor(),
])
# Training data loader
trainloader = DataLoader(
    RFA_Net_Dataset(transforms_=transform, mode="train"),
    batch_size=c.batch_size_train,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)
# Valid data loader
validloader = DataLoader(
    RFA_Net_Dataset(transforms_=transform_valid, mode="valid"),
    batch_size=c.batchsize_valid,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)
# Test data loader
testloader = DataLoader(
    RFA_Net_Dataset(transforms_=transform_test, mode="test"),
    batch_size=c.batchsize_test,
    shuffle=False,
    pin_memory=False,
    num_workers=0,
    drop_last=True
)

# dataset(A, B, C)
if __name__ == '__main__':
    # print('len(trainloader)=',len(trainloader))
    # print('len(validloader)=', len(validloader))
    print('len(testloader)=',len(testloader))
    # for i_batch, data in enumerate(trainloader):
    #     print("trainloader成功")
    # for i_batch, data in enumerate(testloader):
    #     print("testloader成功")


