import glob
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T

def to_rgb(image):
    rgb_image = Image.new("RGB", image.size)
    rgb_image.paste(image)
    return rgb_image
import os

class testdataset(Dataset):
    def __init__(self, transforms_=None, path=None):

        self.transform = transforms_

        files = glob.glob(path + "/*.png")

        self.files = sorted(files, key=lambda x: int(os.path.splitext(os.path.basename(x))[0]))
    def __getitem__(self, index):
        try:
            image = Image.open(self.files[index])
            image = to_rgb(image)
            item = self.transform(image)
            return item

        except:
            return self.__getitem__(index + 1)

    def __len__(self):

        return len(self.files)

transform_val = T.Compose([
    T.CenterCrop(512),
    T.ToTensor(),
])



# Test data loader
testloader = DataLoader(
    testdataset(transforms_=transform_val, path='/media/WRL/D/WRL/FRA-Net-main/other_method/Datasets/test/'),
    batch_size=2,
    shuffle=False,
    pin_memory=True,
    num_workers=0,
    drop_last=True
)
testloader1_2 = DataLoader(
    testdataset(transforms_=transform_val, path='/media/WRL/D/WRL/FRA-Net-main/other_method/Datasets/test1_2/'),
    batch_size=2,
    shuffle=False,
    pin_memory=True,
    num_workers=0,
    drop_last=True
)