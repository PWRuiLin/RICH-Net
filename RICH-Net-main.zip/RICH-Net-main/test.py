

import torch
import torch.nn
import torch.optim
from evaluation_metrics.calculate_PSNR_SSIM import calculate_PSNR_SSIM
from evaluation_metrics.calculate_APD_RMSE import calculate_APD_RMSE_MAE
import numpy as np
from network.model import *
import config as c
from tensorboardX import SummaryWriter
import datasets
import viz
import warnings
from utils.util import gauss_noise, mse_loss, computePSNR, dwt, iwt
import torchvision
from network.Noise import Noise
# from evaluation_metrics.calculate_PSNR_SSIM import calculate_PSNR_SSIM
# from evaluation_metrics.calculate_APD_RMSE import calculate_APD_RMSE_MAE
def load(net, optim, name, load_opt=True):
    state_dicts = torch.load(name)
    network_state_dict = {k: v for k, v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    if load_opt == True:
        optim.load_state_dict(state_dicts['opt'])
    return net, optim

def test(net, step, attack=None, device='cuda', model_num=0):
    net.eval()
    psnr_c = []
    psnr_s = []
    for i_batch, data in enumerate(datasets.testloader):
        data = data.to(device)
        num = data.shape[0] // 2

        cover_image = data[:num]
        secret_image = data[num:num * 2]
        cover_input = dwt(cover_image)
        secret_input = dwt(secret_image)

        forward_input = torch.cat((cover_input, secret_input), 1)
        #    forward:   #
        forward_output = net(forward_input)
        output_z = forward_output.narrow(1, 4 * c.channels_in, forward_output.shape[1] - 4 * c.channels_in)
        output_z_guass = gauss_noise(output_z.shape)

        if step ==0:
            encoded_image_dwt = forward_output.narrow(1, 0, 4 * c.channels_in)
            encoded_image = iwt(encoded_image_dwt)
        if step == 1 or step == 2:
            encoder_input_dwt = torch.cat((forward_output, secret_input), dim=1)
            encoded_image_dwt = net.model_en(encoder_input_dwt)
            encoded_image = iwt(encoded_image_dwt)

        #################
        #   noise attack #
        noise_image = attack([encoded_image, cover_image])
        noise_dwt = dwt(noise_image)


        #################
        #   backward:   #
        #################
        backward_input = torch.cat((noise_dwt, output_z_guass), 1)
        backward_output = net(backward_input, rev=True)
        if step==0:
            decoded_image_dwt = backward_output.narrow(1, 4 * c.channels_in, backward_output.shape[1] - 4 * c.channels_in)
            decoded_image = iwt(decoded_image_dwt)
        if step == 1 or step == 2:
            decoded_image_dwt = net.model_de(backward_output)
            decoded_image = iwt(decoded_image_dwt)

        #################
        #     loss:     #
        #################

        c_loss = mse_loss(encoded_image, cover_image)
        s_loss = mse_loss(decoded_image, secret_image)
        f_loss = mse_loss(encoded_image_dwt.narrow(1, 0, c.channels_in), cover_input.narrow(1, 0, c.channels_in)) +\
                 mse_loss(decoded_image_dwt.narrow(1, 0, c.channels_in), secret_input.narrow(1, 0, c.channels_in))
        decoded_image = decoded_image.clip(0, 1)
        secret_image = secret_image.clip(0, 1)
        encoded_image = encoded_image.clip(0, 1)
        cover_image = cover_image.clip(0, 1)

        psnr_temp = computePSNR(decoded_image, secret_image)
        psnr_s.append(psnr_temp)
        psnr_temp_c = computePSNR(encoded_image, cover_image)
        psnr_c.append(psnr_temp_c)

        cover_images_pad = F.pad(cover_image, (5, 5, 5, 5), value=1.0)
        encoded_images_pad = F.pad(encoded_image, (5, 5, 5, 5), value=1.0)
        noised_images_pad = F.pad(noise_image, (5, 5, 5, 5), value=1.0)
        secret_images_pad = F.pad(secret_image, (5, 5, 5, 5), value=1.0)
        decoded_images_pad = F.pad(decoded_image, (5, 5, 5, 5), value=1.0)
        combination_images = torch.cat((cover_images_pad, encoded_images_pad, noised_images_pad, secret_images_pad, decoded_images_pad), dim=2)
        if i_batch < 1:
            torchvision.utils.save_image(combination_images, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/combination/' + 'model_num=' + str(model_num) + '.png')
        torchvision.utils.save_image(cover_image, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/cover/' + '%.5d.png' % i_batch)
        torchvision.utils.save_image(encoded_image, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/stego/' + '%.5d.png' % i_batch)
        torchvision.utils.save_image(noise_image, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/noise/' + '%.5d.png' % i_batch)
        torchvision.utils.save_image(secret_image, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/secret/' + '%.5d.png' % i_batch)
        torchvision.utils.save_image(decoded_image, '/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/test/secret-rev/' + '%.5d.png' % i_batch)

    # print(psnr_s)
    # print(psnr_c)

def model_init(step, load_path='', load_opt=True, forward_fusion=True, backward_fusion=True):
    net = Model(fusion_forward=forward_fusion, fusion_backward=backward_fusion)

    if step == 0:
        lr = c.lr
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = True
            elif 'enhance' in name:
                para.requires_grad = False

    elif step == 1:
        lr = c.lr
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = False
            elif 'enhance' in name:
                para.requires_grad = True
    elif step == 2:
        lr = c.lr * 0.1
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = True
            elif 'enhance' in name:
                para.requires_grad = True


    optim = torch.optim.Adam(filter(lambda x:x.requires_grad, net.parameters()), lr=lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    net.cuda()
    init_model(net)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)

    if load_path != '':
        net, optim = load(net, optim, load_path, load_opt)
    return net, optim, weight_scheduler

def main(result_folder, attack_method, attack, step, load_path='', model_num=0, Y_channel=False, forward_fusion=True, backward_fusion=True):
    warnings.filterwarnings("ignore")
    if step == 0:
        expinfo = f'{attack_method}_hinet_pretrain'
    elif step == 1:
        expinfo = f'{attack_method}_enhance_pretrain'
    elif step == 2:
        expinfo = f'{attack_method}_enhance_finetune'

    if load_path == '':
        load_opt = False
        if 0 < model_num < 10:  # 0-9
            load_path = f'{result_folder}/models/model_checkpoint_0000' + str(model_num) + '.pth'
        if 9 < model_num < 100:  # 10-99
            load_path = f'{result_folder}/models/model_checkpoint_000' + str(model_num) + '.pth'
        if 99 < model_num < 1000:  # 100-999
            load_path = f'{result_folder}/models/model_checkpoint_00' + str(model_num) + '.pth'
        if 999 < model_num < 10000:  # 1000-9999
            load_path = f'{result_folder}/models/model_checkpoint_0' + str(model_num) + '.pth'
        if step == 1:
            load_path = f'{result_folder}/models/final_state/{attack_method}_hinet_pretrain.pth'
            if 0 < model_num < 10: #0-9
                load_path = f'{result_folder}/models/model_checkpoint_0000'+ str(model_num) + '.pth'
            if 9 < model_num < 100: #10-99
                load_path = f'{result_folder}/models/model_checkpoint_000'+ str(model_num) + '.pth'
            if 99< model_num < 1000:    #100-999
                load_path = f'{result_folder}/models/model_checkpoint_00' + str(model_num) + '.pth'
            if 999 < model_num < 10000: #1000-9999
                load_path = f'{result_folder}/models/model_checkpoint_0' + str(model_num) + '.pth'
        elif step == 2:
            # load_path = f'{result_folder}/models/final_state/{attack_method}_enhance_pretrain.pth'
            if 0 < model_num < 10: #0-9
                load_path = f'{result_folder}/models/model_checkpoint_0000'+ str(model_num) + '.pth'
            if 9 < model_num < 100: #10-99
                load_path = f'{result_folder}/models/model_checkpoint_000'+ str(model_num) + '.pth'
            if 99< model_num < 1000:    #100-999
                load_path = f'{result_folder}/models/model_checkpoint_00' + str(model_num) + '.pth'
            if 999 < model_num < 10000: #1000-9999
                load_path = f'{result_folder}/models/model_checkpoint_0' + str(model_num) + '.pth'
    else:
        load_opt = True
    net, optim, weight_scheduler = model_init(step=step, load_path=load_path, load_opt=load_opt, forward_fusion=forward_fusion, backward_fusion=backward_fusion)
    test(net, attack=attack, step=step, model_num=model_num)

    PSNR_all_s, SSIM_all_s = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test',test_Y=False, secret=True, cover=False, img='png')
    PSNR_all_c, SSIM_all_c = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test',test_Y=False, secret=False, cover=True, img='png')
    NoY_PSNR_ave_c = sum(PSNR_all_c) / len(PSNR_all_c)
    NoY_SSIM_ave_c = sum(SSIM_all_c) / len(SSIM_all_c)
    NoY_PSNR_ave_s = sum(PSNR_all_s) / len(PSNR_all_s)
    NoY_SSIM_ave_s = sum(SSIM_all_s) / len(SSIM_all_s)
    MAE_all_s, RMSE_all_s, MAE_s = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test',test_Y=False, secret=True, cover=False, img='png')
    MAE_all_c, RMSE_all_c, MAE_c = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test',test_Y=False, secret=False, cover=True, img='png')
    NoY_MAE_ave_c = sum(MAE_all_c) / len(MAE_all_c)
    NoY_RMSE_ave_c = sum(RMSE_all_c) / len(RMSE_all_c)
    NoY_MAE_ave_s = sum(MAE_all_s) / len(MAE_all_s)
    NoY_RMSE_ave_s = sum(RMSE_all_s) / len(RMSE_all_s)
    print(f' model_num = {model_num} | NoY | cover_PSNR_AVE={NoY_PSNR_ave_c} | cover_SSIM_AVE={NoY_SSIM_ave_c} | secret_PSNR_AVE={NoY_PSNR_ave_s} | secret_SSIM_AVE={NoY_SSIM_ave_s} ')
    print(f' model_num = {model_num} | NoY | cover_MAE_AVE={NoY_MAE_ave_c} | cover_RMSE_AVE={NoY_RMSE_ave_c} | secret_MAE_AVE={NoY_MAE_ave_s} | secret_RMSE_AVE={NoY_RMSE_ave_s} ')

    if Y_channel:
        PSNR_all_s, SSIM_all_s = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test', test_Y=True, secret=True, cover=False, img='png')
        PSNR_all_c, SSIM_all_c = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test', test_Y=True, secret=False, cover=True, img='png')
        Y_PSNR_ave_c = sum(PSNR_all_c) / len(PSNR_all_c)
        Y_SSIM_ave_c = sum(SSIM_all_c) / len(SSIM_all_c)
        Y_PSNR_ave_s = sum(PSNR_all_s) / len(PSNR_all_s)
        Y_SSIM_ave_s = sum(SSIM_all_s) / len(SSIM_all_s)
        MAE_all_s, RMSE_all_s, MAE_s = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test', test_Y=True,secret=True, cover=False, img='png')
        MAE_all_c, RMSE_all_c, MAE_c = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/test', test_Y=True,secret=False, cover=True, img='png')
        Y_MAE_ave_c = sum(MAE_all_c) / len(MAE_all_c)
        Y_RMSE_ave_c = sum(RMSE_all_c) / len(RMSE_all_c)
        Y_MAE_ave_s = sum(MAE_all_s) / len(MAE_all_s)
        Y_RMSE_ave_s = sum(RMSE_all_s) / len(RMSE_all_s)
        print(f' model_num = {model_num} | Y | cover_PSNR_AVE={Y_PSNR_ave_c} | cover_SSIM_AVE={Y_SSIM_ave_c} | secret_PSNR_AVE={Y_PSNR_ave_s} | secret_SSIM_AVE={Y_SSIM_ave_s}')
        print(f' model_num = {model_num} | Y | cover_MAE_AVE={Y_MAE_ave_c} | cover_RMSE_AVE={Y_RMSE_ave_c} | secret_MAE_AVE={Y_MAE_ave_s} | secret_RMSE_AVE={Y_RMSE_ave_s} ')

    if Y_channel:
        return NoY_PSNR_ave_c, NoY_SSIM_ave_c, NoY_PSNR_ave_s, NoY_SSIM_ave_s, Y_PSNR_ave_c, Y_SSIM_ave_c, Y_PSNR_ave_s, Y_SSIM_ave_s
    else:
        return NoY_PSNR_ave_c, NoY_SSIM_ave_c, NoY_PSNR_ave_s, NoY_SSIM_ave_s
if __name__ == '__main__':
    from utils.load_test_setting import *
    attack = Noise(noise_layers)
    attack_method = "Combined"
    result_folder = result_folder
    Mode = 'special'# order special
    if Mode == 'special':
        step = 2
        i=388
        main(result_folder, attack_method, attack, step, model_num=i, Y_channel=True)
    if Mode == 'order':
        for step in range(0, 3):
            # if step ==0:
            #     for i in range(0, 151):
            #         main(result_folder, attack_method, attack, step, model_num=i, Y_channel=False, forward_fusion=forward_fusion, backward_fusion=backward_fusion)
            # if step ==1:
            #     for i in range(151, 301):
            #         main(result_folder, attack_method, attack, step, model_num=i, Y_channel=False, forward_fusion=forward_fusion, backward_fusion=backward_fusion)
            if step ==2:
                test_result = {
                    "psnr_c": 0.0,
                    "ssim_c": 0.0,
                    "psnr_s": 0.0,
                    "ssim_s": 0.0,
                    "Y_psnr_c": 0.0,
                    "Y_ssim_c": 0.0,
                    "Y_psnr_s": 0.0,
                    "Y_ssim_s": 0.0
                }
                num = 0
                for i in range(301, 601):
                    NoY_PSNR_ave_c, NoY_SSIM_ave_c, NoY_PSNR_ave_s, NoY_SSIM_ave_s, Y_PSNR_ave_c, Y_SSIM_ave_c, Y_PSNR_ave_s, Y_SSIM_ave_s=\
                        main(result_folder, attack_method, attack, step, model_num=i, Y_channel=True, forward_fusion=forward_fusion, backward_fusion=backward_fusion)
                    result = {
                        "psnr_c": NoY_PSNR_ave_c,
                        "ssim_c": NoY_SSIM_ave_c,
                        "psnr_s": NoY_PSNR_ave_s,
                        "ssim_s": NoY_SSIM_ave_s,
                        "Y_psnr_c": Y_PSNR_ave_c,
                        "Y_ssim_c": Y_SSIM_ave_c,
                        "Y_psnr_s": Y_PSNR_ave_s,
                        "Y_ssim_s": Y_SSIM_ave_s
                    }
                    for key in result:
                        test_result[key] += float(result[key])
                    num += 1
                    '''
                    test results
                    '''
                    content = "" + str(i) + " : \n"
                    for key in test_result:
                        content += key + "=" + str(result[key]) + ","
                    content += "\n"

                    with open(test_log, "a") as file:
                        file.write(content)

                    print(content)
                # '''
                # test results
                # '''
                # content = "Average : \n"
                # for key in test_result:
                #     content += key + "=" + str(test_result[key] / num) + ","
                # content += "\n"
                #
                # with open(test_log, "a") as file:
                #     file.write(content)




