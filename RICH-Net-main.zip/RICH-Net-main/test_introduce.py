import torch
import torch.nn
import torch.optim
import torchvision
from other_method.IMN_main.model import Model, init_model
from other_method.GenRAN_main.RFHN.models.model import Model as Model2
from other_method.GenRAN_main.RFHN.models.model import init_model as init_model2
from network.model import Model as Model3
from network.model import init_model as init_model3

from other_method.Datasets import test_datasets
from other_method.IMN_main import dwt_iwt

def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise
def load(name):
    state_dicts = torch.load(name)
    network_state_dict = {k:v for k,v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    try:
        optim.load_state_dict(state_dicts['opt'])
    except:
        print('Cannot load optimizer')
def load2(net, optim, name):
    state_dicts = torch.load(name)
    network_state_dict = {k:v for k,v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    try:
        optim.load_state_dict(state_dicts['opt'])
    except:
        print('Cannot load optimizer for some reason or other')
def load3(net, optim, name, load_opt=True):
    state_dicts = torch.load(name)
    network_state_dict = {k: v for k, v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    if load_opt == True:
        optim.load_state_dict(state_dicts['opt'])
    return net, optim

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
net = Model()
net.cuda()
init_model(net)
net = torch.nn.DataParallel(net, device_ids=[0])
optim = torch.optim.Adam(list(filter(lambda p: p.requires_grad, net.parameters())), lr=10 ** -4.5, betas=(0.5, 0.999), eps=1e-6, weight_decay=1e-5)
load('/media/WRL/D/WRL/FRA-Net-main/other_method/IMN_main/model/model11.pt')
net.eval()

net2 = Model2()
net2.cuda()
init_model2(net2)
net2 = torch.nn.DataParallel(net2, device_ids=[0])
optim2 = torch.optim.Adam(list(filter(lambda p: p.requires_grad, net2.parameters())), lr=10 ** -4.5, betas=(0.5, 0.999), eps=1e-6, weight_decay=1e-5)
load2(net2, optim2, '/media/WRL/D/WRL/FRA-Net-main/other_method/GenRAN_main/RFHN/model/test_model/model_141_fmmrdb_best.pth')  # pth   pt
net2.eval()

net3 = Model3(fusion_forward=True, fusion_backward=True)
for name, para in net3.named_parameters():
    if 'inbs' in name:
        para.requires_grad = True
    elif 'enhance' in name:
        para.requires_grad = True
optim3 = torch.optim.Adam(filter(lambda x:x.requires_grad, net3.parameters()), lr=(10 ** -4.5) * 0.1, betas=(0.5, 0.999), eps=1e-6, weight_decay=1e-5)
net3.cuda()
init_model3(net3)
net3, optim3 = load3(net3, optim3, f'/media/WRL/D/WRL/FRA-Net-main/results/OK-Robustness_Batch8_Fusion_forwardTrue_backwardTrue_HflossTrue_Combined([Identity(), Jpeg_PRIS(90), JpegMask(90), Jpeg(90)])/models/model_checkpoint_00388.pth', False)
net3.eval()


net4 = Model3(fusion_forward=True, fusion_backward=True)
for name, para in net4.named_parameters():
    if 'inbs' in name:
        para.requires_grad = True
    elif 'enhance' in name:
        para.requires_grad = True
optim4 = torch.optim.Adam(filter(lambda x:x.requires_grad, net4.parameters()), lr=(10 ** -4.5) * 0.1, betas=(0.5, 0.999), eps=1e-6, weight_decay=1e-5)
net4.cuda()
init_model3(net4)
net4, optim4 = load3(net4, optim4, f'/media/WRL/D/WRL/FRA-Net-main/results/Robustness_Batch8_Fusion_forwardTrue_backwardTrue_HflossTrue_Combined([Identity(), Jpeg_PRIS(90), JpegMask(90), Jpeg(90), GN(0.001)])/models/model_checkpoint_00342.pth', False)
net4.eval()

dwt = dwt_iwt.DWT()
iwt = dwt_iwt.IWT()
from network.noise_layers.jpeg import JpegTest
from network.noise_layers.gaussian_noise import Gaussian_noise
Jpeg = JpegTest(95)
GN = Gaussian_noise(0.001)
with torch.no_grad():
    image1 = []
    image2 = []
    image3 = []
    image4 = []
    #IMN
    for i, data in enumerate(test_datasets.testloader):
        data = data.to(device)
        mask_face = data[data.shape[0] // 2:, :, :, :]
        protect_face = data[:data.shape[0] // 2, :, :, :]
        # forward
        output = net(torch.cat((dwt(mask_face), dwt(protect_face)), 1))
        output_masked_face = output.narrow(1, 0, 4 * 3)
        output_lost_matrix_m = output.narrow(1, 4 * 3, output.shape[1] - 4 * 3)
        masked_face = iwt(output_masked_face)
        ramdom_martrix_input = gauss_noise(output_lost_matrix_m.shape)
        # noise
        masked_face_Jpeg = Jpeg([masked_face, masked_face])
        masked_face_GN = GN([masked_face, masked_face])
        masked_face_Jpeg_dwt = dwt(masked_face_Jpeg)
        masked_face_GN_dwt = dwt(masked_face_GN)
        # backward
        backward_img = net(torch.cat((output_masked_face, ramdom_martrix_input), 1), rev=True)
        backward_img1 = net(torch.cat((masked_face_Jpeg_dwt, ramdom_martrix_input), 1), rev=True)
        backward_img2 = net(torch.cat((masked_face_GN_dwt, ramdom_martrix_input), 1), rev=True)
        protect_face_rev = iwt(backward_img.narrow(1, 4 * 3, backward_img.shape[1] - 4 * 3))
        protect_face_rev1 = iwt(backward_img1.narrow(1, 4 * 3, backward_img1.shape[1] - 4 * 3))
        protect_face_rev2 = iwt(backward_img2.narrow(1, 4 * 3, backward_img2.shape[1] - 4 * 3))

        protect_face = protect_face.clip(0, 1)
        protect_face_rev = protect_face_rev.clip(0, 1)
        protect_face_rev1 = protect_face_rev1.clip(0, 1)
        protect_face_rev2 = protect_face_rev2.clip(0, 1)
        gap_tensor = torch.full((protect_face.shape[0], protect_face.shape[1], protect_face.shape[2], 10),  1.0, dtype=protect_face.dtype, device=protect_face.device)
        if i ==0:
            image1 = torch.cat((protect_face, gap_tensor, protect_face_rev, gap_tensor, protect_face_rev1, gap_tensor, protect_face_rev2), dim=3)
        # if i ==1:
        #     image2 = torch.cat((protect_face, gap_tensor, protect_facet_rev, gap_tensor, protect_facet_rev1, gap_tensor, protect_facet_rev2), dim=3)
    gap_tensor = torch.full((image1.shape[0], image1.shape[1], 10, image1.shape[3]),  1.0, dtype=image1.dtype, device=image1.device)
    image_all1 = torch.cat((image1, gap_tensor), dim=2)
    torchvision.utils.save_image(image_all1, "/media/WRL/D/WRL/FRA-Net-main/results/imn.png")

    #GenRAN
    for i, data in enumerate(test_datasets.testloader1_2):
        data = data.to(device)
        anonymization_face = data[data.shape[0] // 2:, :, :, :]
        protect_face = data[:data.shape[0] // 2, :, :, :]

        forward_img = net2(torch.cat((dwt(anonymization_face), dwt(protect_face)), 1))
        output_anonymized_face = forward_img.narrow(1, 0, 4 * 3)
        output_z = forward_img.narrow(1, 4 * 3, forward_img.shape[1] - 4 * 3)
        anonymized_face = iwt(output_anonymized_face)
        backward_z = gauss_noise(output_z.shape)

        # noise
        anonymized_face_Jpeg = Jpeg([anonymized_face, anonymized_face])
        anonymized_face_GN = GN([anonymized_face, anonymized_face])
        anonymized_face_Jpeg_dwt = dwt(anonymized_face_Jpeg)
        anonymized_face_GN_dwt = dwt(anonymized_face_GN)

        # backward
        backward_img = net2(torch.cat((output_anonymized_face, backward_z), 1), rev=True)
        backward_img1 = net2(torch.cat((anonymized_face_Jpeg_dwt, backward_z), 1), rev=True)
        backward_img2 = net2(torch.cat((anonymized_face_GN_dwt, backward_z), 1), rev=True)
        protect_face_rev = iwt(backward_img.narrow(1, 4 * 3, backward_img.shape[1] - 4 * 3))
        protect_face_rev1 = iwt(backward_img1.narrow(1, 4 * 3, backward_img1.shape[1] - 4 * 3))
        protect_face_rev2 = iwt(backward_img2.narrow(1, 4 * 3, backward_img2.shape[1] - 4 * 3))

        protect_face = protect_face.clip(0, 1)
        protect_face_rev = protect_face_rev.clip(0, 1)
        protect_face_rev1 = protect_face_rev1.clip(0, 1)
        protect_face_rev2 = protect_face_rev2.clip(0, 1)
        gap_tensor = torch.full((protect_face.shape[0], protect_face.shape[1], protect_face.shape[2], 10), 1.0, dtype=protect_face.dtype, device=protect_face.device)
        if i == 1:
            image2 = torch.cat((protect_face, gap_tensor, protect_face_rev, gap_tensor, protect_face_rev1, gap_tensor, protect_face_rev2), dim=3)
        # if i == 1:
        #     image2 = torch.cat((protect_face, gap_tensor, protect_facet_rev, gap_tensor, protect_facet_rev1, gap_tensor, protect_facet_rev2), dim=3)
    gap_tensor = torch.full((image2.shape[0], image2.shape[1], 10, image2.shape[3]), 1.0, dtype=image2.dtype, device=image2.device)
    image_all2 = torch.cat((image2, gap_tensor), dim=2)
    torchvision.utils.save_image(image_all2, "/media/WRL/D/WRL/FRA-Net-main/results/genran.png")

    #FRA_Net jpeg
    for i, data in enumerate(test_datasets.testloader1_2):
        data = data.to(device)
        anonymization_face = data[data.shape[0] // 2:, :, :, :]
        protect_face = data[:data.shape[0] // 2, :, :, :]
        forward_output = net3(torch.cat((dwt(anonymization_face), dwt(protect_face)), 1))
        output_z_guass = gauss_noise((forward_output.narrow(1, 4 * 3, forward_output.shape[1] - 4 * 3)).shape)
        anonymized_face_dwt = net3.model_en(torch.cat((forward_output, dwt(protect_face)), dim=1))
        anonymized_face = iwt(anonymized_face_dwt)

        # noise
        anonymized_face_Jpeg = Jpeg([anonymized_face, anonymized_face])
        anonymized_face_GN = GN([anonymized_face, anonymized_face])
        anonymized_face_Jpeg_dwt = dwt(anonymized_face_Jpeg)
        anonymized_face_GN_dwt = dwt(anonymized_face_GN)

        # backward
        protect_face_rev = iwt((net3.model_de(net3(torch.cat((anonymized_face_dwt, output_z_guass), 1), rev=True))))
        protect_face_rev1 = iwt((net3.model_de(net3(torch.cat((anonymized_face_Jpeg_dwt, output_z_guass), 1), rev=True))))
        protect_face_rev2 = iwt((net3.model_de(net3(torch.cat((anonymized_face_GN_dwt, output_z_guass), 1), rev=True))))

        protect_face = protect_face.clip(0, 1)
        protect_face_rev = protect_face_rev.clip(0, 1)
        protect_face_rev1 = protect_face_rev1.clip(0, 1)
        protect_face_rev2 = protect_face_rev2.clip(0, 1)

        gap_tensor = torch.full((protect_face.shape[0], protect_face.shape[1], protect_face.shape[2], 10), 1.0, dtype=protect_face.dtype, device=protect_face.device)
        if i == 0:
            image3 = torch.cat((protect_face, gap_tensor, protect_face_rev, gap_tensor, protect_face_rev1, gap_tensor, protect_face_rev2), dim=3)

    gap_tensor = torch.full((image3.shape[0], image3.shape[1], 10, image3.shape[3]), 1.0, dtype=image3.dtype, device=image3.device)
    image_all3 = torch.cat((image3, gap_tensor), dim=2)
    torchvision.utils.save_image(image_all3, "/media/WRL/D/WRL/FRA-Net-main/results/ours(jpeg_model).png")

    #FRA_Net jpeg gn
    for i, data in enumerate(test_datasets.testloader1_2):
        data = data.to(device)
        anonymization_face = data[data.shape[0] // 2:, :, :, :]
        protect_face = data[:data.shape[0] // 2, :, :, :]
        forward_output = net4(torch.cat((dwt(anonymization_face), dwt(protect_face)), 1))
        output_z_guass = gauss_noise((forward_output.narrow(1, 4 * 3, forward_output.shape[1] - 4 * 3)).shape)
        anonymized_face_dwt = net4.model_en(torch.cat((forward_output, dwt(protect_face)), dim=1))
        anonymized_face = iwt(anonymized_face_dwt)

        # noise
        anonymized_face_Jpeg = Jpeg([anonymized_face, anonymized_face])
        anonymized_face_GN = GN([anonymized_face, anonymized_face])
        anonymized_face_Jpeg_dwt = dwt(anonymized_face_Jpeg)
        anonymized_face_GN_dwt = dwt(anonymized_face_GN)

        # backward
        protect_face_rev = iwt((net4.model_de(net4(torch.cat((anonymized_face_dwt, output_z_guass), 1), rev=True))))
        protect_face_rev1 = iwt((net4.model_de(net4(torch.cat((anonymized_face_Jpeg_dwt, output_z_guass), 1), rev=True))))
        protect_face_rev2 = iwt((net4.model_de(net4(torch.cat((anonymized_face_GN_dwt, output_z_guass), 1), rev=True))))

        protect_face = protect_face.clip(0, 1)
        protect_face_rev = protect_face_rev.clip(0, 1)
        protect_face_rev1 = protect_face_rev1.clip(0, 1)
        protect_face_rev2 = protect_face_rev2.clip(0, 1)

        gap_tensor = torch.full((protect_face.shape[0], protect_face.shape[1], protect_face.shape[2], 10), 1.0, dtype=protect_face.dtype, device=protect_face.device)
        if i == 0:
            image4 = torch.cat((protect_face, gap_tensor, protect_face_rev, gap_tensor, protect_face_rev1, gap_tensor, protect_face_rev2), dim=3)

    gap_tensor = torch.full((image4.shape[0], image4.shape[1], 10, image4.shape[3]), 1.0, dtype=image4.dtype, device=image4.device)
    image_all4 = torch.cat((image4, gap_tensor), dim=2)
    torchvision.utils.save_image(image_all4, "/media/WRL/D/WRL/FRA-Net-main/results/ours(jpeg_gn_model).png")

    torchvision.utils.save_image(torch.cat((image1, image2, image3), dim=2), "/media/WRL/D/WRL/FRA-Net-main/results/imn_genran_ours(jpeg_model).png")
    torchvision.utils.save_image(torch.cat((image1, image2, image4), dim=2), "/media/WRL/D/WRL/FRA-Net-main/results/imn_genran_ours(jpeg_gn_model).png")
    torchvision.utils.save_image(torch.cat((image1, image2, image3, image4), dim=2), "/media/WRL/D/WRL/FRA-Net-main/results/imn_genran_ours(jpeg_model)_ours(jpeg_gn_model).png")

