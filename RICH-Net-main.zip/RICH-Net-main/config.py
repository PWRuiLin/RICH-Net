# Super parameters
clamp = 2.0
channels_in = 3
log10_lr = -4.5
lr = 10 ** log10_lr
epochs = 2000                                                                                                       #lamda 2000
# muqian 2000+1025 = 3000
weight_decay = 1e-5
init_scale = 0.01

lamda_guide = 1
lamda_reconstruction = 1    #10
lamda_low_frequency = 1     #10
device_ids = [0]

# Train:
batch_size_train = 8    #12     #16
cropsize_train = 128
resize_train = (128, 128)
cropsize_valid = 128
resize_valid = (128, 128)
betas = (0.5, 0.999)
weight_step = 10
gamma = 0.95
# weight_step = 250
# gamma = 0.5
#Dense block: weight_step=500; gamma=0.5
# ValID:
batchsize_valid = 8  #12
shuffle_val = False
val_freq = 10
cropsize_valid_CelebAHQ = 128
cropsize_valid_CelebA = 128
cropsize_valid_LFW = 128

#TEST
batchsize_test = 2
resize_test = (128, 128)
cropsize_test = 128
# Dataset
Dataset_TRAIN_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_VALID_mode = 'CelebA-HQ'    # CelebA / CelebA-HQ
Dataset_TEST_mode = 'CelebA-HQ'     # 4Datasets png /CelebA-HQ jpg/ CelebA jpg/ LFW jpg/ FFHQ png/ AGE_ADULTS / experiment1_8 experiment1_2 png/ experiment2 / experiment3 png

TRAIN_PATH_CelebAHQ = './Dataset/CelebA-HQ/train/'
TRAIN_PATH_CelebA = './Dataset/CelebA/train/'
TRAIN_PATH_DIV2K = './Dataset/DIV2K/DIV2K_train_HR/'

VALID_PATH_CelebAHQ = './Dataset/CelebA-HQ/valid/'
VALID_PATH_CelebA = './Dataset/CelebA/valid/'
VALID_PATH_DIV2K = './Dataset/DIV2K/DIV2K_valid_HR/'

TEST_PATH_4Datasets = './Dataset/4Datasets/test_HighQuality/'  #test_HighQuality  test
TEST_PATH_CelebAHQ = './Dataset/CelebA-HQ/test_HighQuality/'  #test_HighQuality  test
TEST_PATH_DIV2K = './Dataset/DIV2K/Face_test1/'
TEST_PATH_CelebA = './Dataset/CelebA/test_HighQuality/' #test_HighQuality  test
TEST_PATH_FFHQ = './Dataset/FFHQ/test_HighQuality/' #test_HighQuality  test
TEST_PATH_LFW = './Dataset/LFW/test_HighQuality/' #test_HighQuality  test
TEST_PATH_AGE_ADULTS = './Dataset/AGE_ADULTS/test_HighQuality/'#test_HighQuality  test
TEST_PATH_experiment1_8 = './Dataset/experiments/experiment1/8/'
TEST_PATH_experiment1_2 = './Dataset/experiments/experiment1/2/'
TEST_PATH_experiment2 = './Dataset/experiments/experiment2/'
TEST_PATH_experiment3 = './Dataset/experiments/experiment3/'

# Display and logging:
loss_display_cutoff = 2.0
loss_names = ['L', 'lr']
silent = False
live_visualization = False
progress_bar = False


# Saving checkpoints:
loss = 'MSE' # MAE MSE
MODEL_PATH = 'results/model/model_Jpeg/'

checkpoint_on_error = False
SAVE_freq = 1

IMAGE_TEST_PATH = 'results/image/test/'
IMAGE_TEST_PATH_cover = IMAGE_TEST_PATH + 'cover/'
IMAGE_TEST_PATH_secret = IMAGE_TEST_PATH + 'secret/'
IMAGE_TEST_PATH_stego = IMAGE_TEST_PATH + 'stego/'
IMAGE_TEST_PATH_secret_rev = IMAGE_TEST_PATH + 'secret-rev/'
IMAGE_TEST_PATH_resi_cover = IMAGE_TEST_PATH + 'resi-cover/'
IMAGE_TEST_PATH_resi_secret = IMAGE_TEST_PATH + 'resi-secret/'
IMAGE_TEST_PATH_output_r = IMAGE_TEST_PATH + 'r/'
IMAGE_TEST_PATH_backward_z = IMAGE_TEST_PATH + 'z/'

IMAGE_TEST_PATH_noise = IMAGE_TEST_PATH + 'noise/'
IMAGE_TEST_PATH_residual = IMAGE_TEST_PATH + 'residual/'
IMAGE_TEST_PATH_frequency = IMAGE_TEST_PATH + 'frequency/'

IMAGE_TRAIN_PATH = 'results/image/train/'
IMAGE_TRAIN_PATH_cover = IMAGE_TRAIN_PATH + 'cover/'
IMAGE_TRAIN_PATH_secret = IMAGE_TRAIN_PATH + 'secret/'
IMAGE_TRAIN_PATH_steg = IMAGE_TRAIN_PATH + 'stego/'
IMAGE_TRAIN_PATH_noise = IMAGE_TRAIN_PATH + 'noise/'
IMAGE_TRAIN_PATH_secret_rev = IMAGE_TRAIN_PATH + 'secret-rev/'
IMAGE_TRAIN_PATH_z = IMAGE_TRAIN_PATH + 'z/'
# Load:
suffix = 'model_best500.pth'#model_jpeg_best   model_best

tain_next = False
trained_epoch = 0

image_save_train_valid = True

