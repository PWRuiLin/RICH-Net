from math import exp
import torch
import torch.nn as nn
import config as c
from network.rrdb_denselayer import ResidualDenseBlock_out

# DWT YES
class INV_block(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        self.r = subnet_constructor(self.split_len1, self.split_len2)
        # η
        self.y = subnet_constructor(self.split_len1, self.split_len2)
        # φ
        self.f = subnet_constructor(self.split_len2, self.split_len1)

    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x, rev=False):
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))

        if not rev:

            t2 = self.f(x2)
            y1 = x1 + t2
            s1, t1 = self.r(y1), self.y(y1)
            y2 = self.e(s1) * x2 + t1

        else:

            s1, t1 = self.r(x1), self.y(x1)
            y2 = (x2 - t1) / self.e(s1)
            t2 = self.f(y2)
            y1 = (x1 - t2)

        return torch.cat((y1, y2), 1)

class INV_lightweight_block(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        self.r = subnet_constructor(self.split_len1, self.split_len2)
        # η
        self.y = subnet_constructor(self.split_len1, self.split_len2)
        # φ
        self.f = nn.Conv2d(self.split_len1 + self.split_len1, self.split_len1, kernel_size=1)#subnet_constructor(self.split_len2, self.split_len1)

    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x, rev=False): # cover secret
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))

        if not rev:
            s1, t1 = self.r(x2), self.y(x2)
            y1 = self.e(s1) * x2 + t1
            y2 = x2
            cat = torch.cat((y1, y2), 1)
            out = self.f(cat)

        else:
            cat = torch.cat((x1, x2), 1)
            out = self.f(cat)
            x1, x2 = (out.narrow(1, 0, self.split_len1),
                      out.narrow(1, self.split_len1, self.split_len2))
            s1, t1 = self.r(x2), self.y(x2)
            y1 = (x1 - t1) / self.e(s1)
            y2 = x2
            out = torch.cat((y1, y2), 1)

        return out












class INV_block_en(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        # self.r = subnet_constructor(self.split_len1, self.split_len2)
        # η
        # self.y = subnet_constructor(self.split_len1, self.split_len2)
        # φ
        self.f1 = subnet_constructor(self.split_len2, self.split_len1)
        self.f2 = subnet_constructor(self.split_len2, self.split_len1)
    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x):
        x1, x2, x3 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2), x.narrow(1, self.split_len1 * 2, self.split_len2))

        t2 = self.f1(x2)
        t3 = self.f2(x3)
        y1 = x1 + t2 + t3

        return y1
class INV_block_de(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        self.r = subnet_constructor(self.split_len1, self.split_len2)
        # η
        self.y = subnet_constructor(self.split_len1, self.split_len2)
        # φ
        # self.f = subnet_constructor(self.split_len2, self.split_len1)

    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x):
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))

        s1, t1 = self.r(x1), self.y(x1)
        y2 = (x2 - t1) / self.e(s1) + x2

        return y2

class INV_block_en_no(nn.Module):
    def __init__(self, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
    def forward(self, x):
        x1, x2, x3 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2), x.narrow(1, self.split_len1 * 2, self.split_len2))
        y1 = x1

        return y1
class INV_block_de_no(nn.Module):
    def __init__(self, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
    def forward(self, x):
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))
        y2 = x2

        return y2
class ConvBNRelu(nn.Module):
    def __init__(self, channels_in, channels_out, stride=1):
        super(ConvBNRelu, self).__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(channels_in, channels_out, 3, stride, padding=1),
            nn.BatchNorm2d(channels_out),
            nn.LeakyReLU(inplace=True)
        )
    def forward(self, x):
        return self.layers(x)

class INV_block_enn(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        # self.r = subnet_constructor(self.split_len1, self.split_len2)
        # η
        # self.y = subnet_constructor(self.split_len1, self.split_len2)
        # φ
        self.f1 = subnet_constructor(self.split_len2, self.split_len1 * 3)
        self.f2 = subnet_constructor(self.split_len2, self.split_len1 * 3)
        self.concat_layer1 = ConvBNRelu(6 * self.split_len1, self.split_len1)
        self.concat_layer2 = nn.Conv2d(self.split_len1 + self.split_len1, self.split_len1, kernel_size=1)

    def forward(self, x):
        x1, x2, x3 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2), x.narrow(1, self.split_len1 * 2, self.split_len2))

        t1 = self.f1(x1)
        t2 = self.f2(x2)

        concat1 = torch.cat([t1, t2], dim=1)
        intermediate1 = self.concat_layer1(concat1)

        intermediate2 = torch.cat([intermediate1, x3], dim=1)
        y = self.concat_layer2(intermediate2)

        return y


class INV_block_dee(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        self.r = subnet_constructor(self.split_len1, self.split_len2 * 3)
        # η
        self.y = subnet_constructor(self.split_len1, self.split_len2 * 3)
        #
        self.g = subnet_constructor(self.split_len2, self.split_len1 * 3)
        # φ
        self.f = subnet_constructor(self.split_len2, self.split_len1 * 3)

        self.concat_layer = ConvBNRelu(6 * self.split_len1, self.split_len1 * 3)
        self.final_layer = nn.Conv2d(3 * self.split_len1, self.split_len1, kernel_size=1)#ConvBNRelu(3 * self.split_len1, self.split_len1)
    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x):
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))

        s1, t1 = self.r(x1), self.y(x1)
        y2 = self.g(x2)
        y1 = (y2 - t1) / self.e(s1)
        y3 = self.f(x2)
        concat1 = torch.cat([y1, y3], dim=1)
        y3 = self.concat_layer(concat1)
        y = self.final_layer(y3)

        return y