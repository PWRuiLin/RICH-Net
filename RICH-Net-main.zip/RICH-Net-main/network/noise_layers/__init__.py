import random


def get_random_float(float_range: [float]):
	return random.random() * (float_range[1] - float_range[0]) + float_range[0]


def get_random_int(int_range: [int]):
	return random.randint(int_range[0], int_range[1])


from .identity import Identity
from .crop import Crop as C
from .crop import Cropout as CO
from .crop import Dropout as DO
from .crop import RandomCrop

from .gaussian_noise import Gaussian_noise as GN
from .middle_filter import MF
from .gaussian_filter import GF as GB
# from .gaussian_blur import Gaussian_blur
from .salt_pepper_noise import SP
from .jpeg import Jpeg, JpegSS, JpegMask, JpegTest, Jpeg_compression, RandomJpegSS, RandomJpegMask, RandomJpeg
from .DiffJPEG_PRIS import DiffJPEG as Jpeg_PRIS
from .combined import Combined
from .osn import Osn
# from .gaussian_blur import Gaussian_blur
from .JPEGA import JPEG_Compression1
