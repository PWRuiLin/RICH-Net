import math
import torch
import torch.optim
import torch.nn as nn
import config as c
import torch.nn.functional as F
from network.hinet import Hinet, Hinet_en, Hinet_de, Hinet_enn, Hinet_dee, Hinet12
import network.module_util as mutil
from torch.nn.init import _calculate_fan_in_and_fan_out

# class Model(nn.Module):
#     def __init__(self):
#         super(Model, self).__init__()
#
#         self.model = Hinet()
#         self.model_en = Hinet_en()
#         self.model_de = Hinet_de()
#
#     def forward(self, x, rev=False):
#
#         if not rev:
#             out = self.model(x)
#
#         else:
#             out = self.model(x, rev=True)
#
#         return out

class Model(nn.Module):
    def __init__(self, fusion_forward=True, fusion_backward=True):
        super(Model, self).__init__()

        self.model = Hinet()
        self.model_en = Hinet_en(fusion_forward = fusion_forward)
        self.model_de = Hinet_de(fusion_backward = fusion_backward)

    def forward(self, x, rev=False):

        if not rev:
            out = self.model(x)

        else:
            out = self.model(x, rev=True)

        return out

def init_model(mod):
    for key, param in mod.named_parameters():
        split = key.split('.')
        if param.requires_grad:
            param.data = c.init_scale * torch.randn(param.data.shape).cuda()
            if split[-2] == 'conv5':
                param.data.fill_(0.)







class SAFM(nn.Module):
    def __init__(self, dim, DWT=True,  bias=True): # NoDWT:1      YesDWT:4
        super().__init__()
        n_levels=4
        #     n_levels=1
        self.n_levels = n_levels
        chunk_dim = dim // n_levels

        self.conv1 = nn.Conv2d(chunk_dim, chunk_dim, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(chunk_dim * 2, chunk_dim, 3, 1, 1, bias=bias)
        # Feature Aggregation
        self.aggr = nn.Conv2d(dim, dim, 1, 1, 0, bias=bias)

        # Activation
        self.lrelu = nn.LeakyReLU(inplace=True)# self.act = nn.GELU()

    def forward(self, x):
        h, w = x.size()[-2:]

        xc = x.chunk(self.n_levels, dim=1)
        out = []
        for i in range(self.n_levels):
            if i > 0:
                p_size = (h // 2 ** i, w // 2 ** i)
                s = F.adaptive_max_pool2d(xc[i], p_size)
                s1 = self.conv1(s)
                s2 = self.conv2(torch.cat((s, s1), dim=1))
                s_out = F.interpolate(s2, size=(h, w), mode='nearest')
            else:
                s1 = self.conv1(xc[i])
                s_out = self.conv2(torch.cat((xc[i], s1), dim=1))
            out.append(s_out)

        out = self.aggr(torch.cat(out, dim=1))
        out = self.lrelu(out) * x
        return out
class CCM(nn.Module):
    def __init__(self, dim, bias=True):
        super().__init__()
        self.conv1 = nn.Conv2d(dim, dim * 2, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(dim * 2, dim, 1, 1, 0, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)
        mutil.initialize_weights([self.conv2], 0.)
    def forward(self, x):
        out = self.lrelu(self.conv1(x))
        out = self.conv2(out)
        return out
class FMM(nn.Module):
    def __init__(self, input, DWT=True, bias=True):
        super().__init__()
        self.safm = SAFM(input, DWT=DWT, bias=bias)
        self.ccm = CCM(input, bias=bias)
    def forward(self, x):
        out = self.safm(x) + x
        out = self.ccm(out) + out
        return out


class ResidualDenseBlock(nn.Module):#FeatureMixingResidualDenseBlockplus_out
    def __init__(self, input, output, DWT=True, bias=True):
        super(FeatureMixResidualDenseBlock, self).__init__()
        self.conv = nn.Conv2d(input, input + 61, 1, 1, 0, bias=bias)
        self.conv1 = nn.Conv2d(input, 61, 3, 1, 1, bias=bias)
        self.fmm = FMM(input + 61, DWT=DWT, bias=bias) #44
        self.conv2 = nn.Conv2d(input + 61, output, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)
        mutil.initialize_weights([self.conv2], 0.)
    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        fmm = self.fmm(torch.cat((x, x1), 1))
        fmm = fmm + self.lrelu(self.conv(x))
        x5 = self.conv2(fmm)
        return x5

class FeatureMixResidualDenseBlock(nn.Module):#FeatureMixingResidualDenseBlockplus_out
    def __init__(self, input, output, DWT=True, bias=True):
        super(FeatureMixResidualDenseBlock, self).__init__()
        self.conv = nn.Conv2d(input, input + 61, 1, 1, 0, bias=bias)
        self.conv1 = nn.Conv2d(input, 61, 3, 1, 1, bias=bias)
        self.fmm = FMM(input + 61, DWT=DWT, bias=bias) #44
        self.conv2 = nn.Conv2d(input + 61, output, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)
        mutil.initialize_weights([self.conv2], 0.)
    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        fmm = self.fmm(torch.cat((x, x1), 1))
        fmm = fmm + self.lrelu(self.conv(x))
        x5 = self.conv2(fmm)
        return x5
class ChannelAttention(nn.Module):
    def __init__(self, channel, reduction=16):
        super().__init__()
        self.maxpool = nn.AdaptiveMaxPool2d(1)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.se = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
			nn.LeakyReLU(inplace=True),
			nn.Conv2d(channel // reduction, channel, 1, bias=False),
		)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_result = self.maxpool(x)
        avg_result = self.avgpool(x)
        max_out = self.se(max_result)
        avg_out = self.se(avg_result)
        output = self.sigmoid(max_out + avg_out)
        return output
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2)
        self.relu = nn.LeakyReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_result, _ = torch.max(x, dim=1, keepdim=True)
        avg_result = torch.mean(x, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], 1)
        output = self.relu(self.conv(result))
        output = self.sigmoid(output)
        return output

class ChannelAttentionFeatureMixResidualDenseBlock(nn.Module):#FeatureMixingResidualDenseBlockplus_out
    def __init__(self, input, output, DWT=True, bias=True):
        super(ChannelAttentionFeatureMixResidualDenseBlock, self).__init__()
        self.conv = nn.Conv2d(input, input + 61, 1, 1, 0, bias=bias)
        self.conv1 = nn.Conv2d(input, 61, 3, 1, 1, bias=bias)
        self.fmm = FMM(input + 61, DWT=DWT, bias=bias) #44
        self.ca = ChannelAttention(input + 61)
        self.conv2 = nn.Conv2d(input + 61, output, 3, 1, 1, bias=bias)

        self.lrelu = nn.LeakyReLU(inplace=True)
        mutil.initialize_weights([self.conv2], 0.)
    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        fmm = self.fmm(torch.cat((x, x1), 1))
        fmm = fmm + self.lrelu(self.conv(x))
        ca = self.ca(fmm) * fmm
        x5 = self.conv2(ca)
        return x5
class SpatialAttentionFeatureMixResidualDenseBlock(nn.Module):#FeatureMixingResidualDenseBlockplus_out
    def __init__(self, input, output, DWT=True, bias=True):
        super(SpatialAttentionFeatureMixResidualDenseBlock, self).__init__()
        self.conv = nn.Conv2d(input, input + 61, 1, 1, 0, bias=bias)
        self.conv1 = nn.Conv2d(input, 61, 3, 1, 1, bias=bias)
        self.fmm = FMM(input + 61, DWT=DWT, bias=bias)  # 44
        self.sa = SpatialAttention(input + 61)
        self.conv2 = nn.Conv2d(input + 61, output, 3, 1, 1, bias=bias)

        self.lrelu = nn.LeakyReLU(inplace=True)
        mutil.initialize_weights([self.conv2], 0.)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        fmm = self.fmm(torch.cat((x, x1), 1))
        fmm = fmm + self.lrelu(self.conv(x))
        print(fmm.shape)
        print(self.sa(fmm).shape)
        sa = self.sa(fmm) * fmm
        x5 = self.conv2(sa)
        return x5

class Image_Fusion_Enhance_Module(nn.Module):
    def __init__(self, input, output, bias=True):
        super(Image_Fusion_Enhance_Module, self).__init__()
        self.cafmrdb = ChannelAttentionFeatureMixResidualDenseBlock(input, input, bias=bias)
        self.safmrdb = SpatialAttentionFeatureMixResidualDenseBlock(input, output, bias=bias)
    def forward(self, x):
        y = self.cafmrdb(x)


        y = self.safmrdb(y)
        print(y)
        return y

if __name__ == '__main__':
	image = torch.randn(1, 3, 128, 128)

	model = Image_Fusion_Enhance_Module(3,3)  # FMRDBplus_out:50756 ResidualDenseBlock_out:84380
	output = model(image)
	print(f'params: {sum(map(lambda x: x.numel(), model.parameters()))}')
	print(output.shape)