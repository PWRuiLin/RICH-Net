from aip import AipFace
from base64 import b64encode
from PIL import Image
import io
import os
APP_ID = '38879067'
API_KEY = 'ZLOKtERseZG0aFZwEcKtgxvg'
SECRET_KEY = 'Dxo7EQyZ35aMdZxEKPXQ646vRF28Z3ND'
client = AipFace(APP_ID, API_KEY, SECRET_KEY)
def load_image(path):
    # 打开图像文件
    with open(path, "rb") as img_file:
        img_data = img_file.read()

    # 使用PIL库打开图像并将其转换为PNG格式的字节流
    img = Image.open(io.BytesIO(img_data))

    # 使用 io.BytesIO() 将图像保存为字节流，再将其进行Base64编码
    with io.BytesIO() as byte_io:
        img.save(byte_io, format="png")  # 保存为PNG格式
        byte_io.seek(0)  # 移动到流的起始位置
        img_b64 = b64encode(byte_io.read()).decode('utf-8')  # 进行Base64编码并解码为字符串
    return img_b64

def detect_face(image):
    """调用人脸检测接口"""
    result = client.detect(image, 'BASE64', options={'face_field': 'age,gender,beauty'})
    return result

def search_face(image, group_id):
    """调用人脸搜索接口"""
    options = {
        'group_id_list': group_id  # 直接使用字符串格式
    }
    result = client.search(image, 'BASE64', options)
    return result

image = load_image('/media/WRL/D/WRL/HiNet_Robust_main/results/image/previous/141/secret/0.png')  # 替换为你的图像路径
faces = detect_face(image)  # 进行人脸检测

search_result = search_face(image, 'group_id')  # 进行人脸搜索，'group1'为已创建的人脸组ID
print(search_result)
