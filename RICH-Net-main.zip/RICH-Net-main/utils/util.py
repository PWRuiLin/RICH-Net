import os
import logging
import random
from datetime import datetime
import torch
from network.Unet_common import IWT, DWT


def get_timestamp():
    return datetime.now().strftime('%y%m%d-%H%M%S')

def setup_logger(logger_name, root, phase, level=logging.INFO, screen=False, tofile=False):
    '''set up logger'''
    lg = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s.%(msecs)03d - %(levelname)s: %(message)s',
                                  datefmt='%y-%m-%d %H:%M:%S')
    lg.setLevel(level)
    if tofile:
        log_file = os.path.join(root, phase + '_{}.log'.format(get_timestamp()))
        fh = logging.FileHandler(log_file, mode='w')
        fh.setFormatter(formatter)
        lg.addHandler(fh)
    if screen:
        sh = logging.StreamHandler()
        sh.setFormatter(formatter)
        lg.addHandler(sh)

def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise

def mse_loss(a, b):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(a, b)
    return loss

def get_parameter_number(net):
    total_num = sum(p.numel() for p in net.parameters())
    trainable_num = sum(p.numel() for p in net.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}

def computePSNR(origin,pred):
    mse = torch.mean((origin/1.0 - pred/1.0) ** 2 )
    if mse < 1.0e-10:
      return 100
    return 10 * torch.log10(1.0/mse).item()

iwt = IWT()
dwt = DWT()

def triplet_loss(a, b, c):
    loss_fn = torch.nn.TripletMarginLoss(margin=2.0, p=2)
    loss = loss_fn(a, b, c)
    return loss

def pairwise_loss(a, b):
    loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
    loss = loss_fn(a, b)
    return loss

# class triplet_loss(torch.nn.Module):
#     def __init__(self, margin=1.0):
#         super(triplet_loss, self).__init__()
#         self.margin = margin
#
#     def forward(self, anchor, positive, negative):
#         loss_fn = torch.nn.MSELoss(reduce=True, size_average=False)
#
#         # 计算锚点和正样本之间的L2距离
#         d_pos = loss_fn(anchor, positive)  # 按元素计算均方误差
#
#         # 计算锚点和负样本之间的L2距离
#         d_neg = loss_fn(anchor, negative)  # 按元素计算均方误差
#
#         # 计算三元组损失
#         loss = torch.clamp(d_pos - d_neg + self.margin, min=0.0)
#         print(f'triplet_loss = {loss} | d_pos = {d_pos} | d_neg = {d_neg} ')
#         return loss  # 返回平均损失
