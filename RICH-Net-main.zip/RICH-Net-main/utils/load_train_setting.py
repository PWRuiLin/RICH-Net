from .settings import *
import os
import time

'''
params setting
'''
settings = JsonConfig()
settings.load_json_file("train_settings.json")
project_name = settings.project_name
noise_layers = settings.noise_layers
train_continue_path = settings.train_continue_path
forward_fusion = settings.forward_fusion
backward_fusion = settings.backward_fusion
hfloss = settings.hfloss
# idloss = settings.idloss
'''
file preparing
'''
full_project_name = project_name + '_Fusion_forward'+ str(forward_fusion) + '_backward'+ str(backward_fusion) + '_Hfloss' + str(hfloss) #+ '_idloss' + str(idloss)
for noise in noise_layers:
	full_project_name += "_" + noise
result_folder = "results/" + time.strftime(full_project_name + "__%Y_%m_%d__%H_%M_%S", time.localtime()) + "/"#time.strftime(full_project_name + "__%Y_%m_%d__%H_%M_%S", time.localtime()) + "/"
if not os.path.exists(result_folder): os.mkdir(result_folder)
if not os.path.exists(result_folder + "images/"): os.mkdir(result_folder + "images/")
if not os.path.exists(result_folder + "models/"): os.mkdir(result_folder + "models/")
if not os.path.exists(result_folder + "models/final_state/"): os.mkdir(result_folder + "models/final_state/")

if not os.path.exists(result_folder + "images/test/"): os.mkdir(result_folder + "images/test/")
if not os.path.exists(result_folder + "images/train/"): os.mkdir(result_folder + "images/train/")
if not os.path.exists(result_folder + "images/valid/"): os.mkdir(result_folder + "images/valid/")

if not os.path.exists(result_folder + "images/train/cover/"): os.mkdir(result_folder + "images/train/cover/")
if not os.path.exists(result_folder + "images/train/stego/"): os.mkdir(result_folder + "images/train/stego/")
if not os.path.exists(result_folder + "images/train/noise/"): os.mkdir(result_folder + "images/train/noise/")
if not os.path.exists(result_folder + "images/train/secret/"): os.mkdir(result_folder + "images/train/secret/")
if not os.path.exists(result_folder + "images/train/secret-rev/"): os.mkdir(result_folder + "images/train/secret-rev/")
if not os.path.exists(result_folder + "images/train/combination/"): os.mkdir(result_folder + "images/train/combination/")

if not os.path.exists(result_folder + "images/valid/cover/"): os.mkdir(result_folder + "images/valid/cover/")
if not os.path.exists(result_folder + "images/valid/stego/"): os.mkdir(result_folder + "images/valid/stego/")
if not os.path.exists(result_folder + "images/valid/noise/"): os.mkdir(result_folder + "images/valid/noise/")
if not os.path.exists(result_folder + "images/valid/secret/"): os.mkdir(result_folder + "images/valid/secret/")
if not os.path.exists(result_folder + "images/valid/secret-rev/"): os.mkdir(result_folder + "images/valid/secret-rev/")
if not os.path.exists(result_folder + "images/valid/combination/"): os.mkdir(result_folder + "images/valid/combination/")

if not os.path.exists(result_folder + "images/test/cover/"): os.mkdir(result_folder + "images/test/cover/")
if not os.path.exists(result_folder + "images/test/stego/"): os.mkdir(result_folder + "images/test/stego/")
if not os.path.exists(result_folder + "images/test/noise/"): os.mkdir(result_folder + "images/test/noise/")
if not os.path.exists(result_folder + "images/test/secret/"): os.mkdir(result_folder + "images/test/secret/")
if not os.path.exists(result_folder + "images/test/secret-rev/"): os.mkdir(result_folder + "images/test/secret-rev/")
if not os.path.exists(result_folder + "images/test/combination/"): os.mkdir(result_folder + "images/test/combination/")

with open(result_folder + "/train_params.txt", "w") as file:
	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
														time.localtime()) + "-----------------------\n"

	for item in settings.get_items():
		content += item[0] + " = " + str(item[1]) + "\n"

	print(content)
	file.write(content)
with open(result_folder + "/train_log.txt", "w") as file:
	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
														time.localtime()) + "-----------------------\n"
	file.write(content)
with open(result_folder + "/val_log.txt", "w") as file:
	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
														time.localtime()) + "-----------------------\n"
	file.write(content)
