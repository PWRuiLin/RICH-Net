from .settings import *
import os
import time

'''
params setting
'''
filename = "test_settings.json"
settings = JsonConfig()
settings.load_json_file(filename)
noise_layers = settings.noise_layers
forward_fusion = settings.forward_fusion
backward_fusion = settings.backward_fusion

result_folder = "results/" + settings.result_folder

test_base = "/test_"
for layer in settings.noise_layers:
	test_base += layer + "_"
test_param = result_folder + test_base + "_params.json"
test_log = result_folder + test_base + "_log.txt"

with open(test_param, "w") as file:
	content = ""
	for item in settings.get_items():
		content += item[0] + " = " + str(item[1]) + "\n"
	print(content)

	with open(filename, "r") as setting_file:
		content = setting_file.read()
		file.write(content)

with open(test_log, "w") as file:
	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
														time.localtime()) + "-----------------------\n"
	file.write(content)
