#!/usr/bin/env python
import torch
import torch.nn
import torch.optim
import numpy as np
from network.model import *
import config as c
from tensorboardX import SummaryWriter
import datasets
import viz
import warnings
from utils.util import gauss_noise, mse_loss, computePSNR, dwt, iwt
import torchvision
from network.Noise import Noise
from evaluation_metrics.calculate_PSNR_SSIM import calculate_PSNR_SSIM
from evaluation_metrics.calculate_APD_RMSE import calculate_APD_RMSE_MAE
import random
import torch.backends.cudnn as cudnn
cudnn.benchmark = True# 开启 cuDNN 基准测试（只有在输入数据大小固定时才推荐开启）
# def set_seed(seed):
#     random.seed(seed)
#     # np.random.seed(seed)
#     torch.manual_seed(seed)
#     torch.cuda.manual_seed(seed)
#     torch.cuda.manual_seed_all(seed)  # If you are using multi-GPU
#     torch.backends.cudnn.deterministic = True
#     torch.backends.cudnn.benchmark = False  # If you need fast training, set to False

def load(net, optim, name, load_opt=True):
    state_dicts = torch.load(name)
    network_state_dict = {k: v for k, v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    if load_opt == True:
        optim.load_state_dict(state_dicts['opt'])
    return net, optim


def train_epoch(net, step, optim=None, attack=None, i_epoch=None, writer=None, mode='train', lam=([0.0,0.0,0.0], [0.0,0.0,0.0], [0.0,0.0,0.0]), device='cuda', hfloss=True):
    r_loss_list, g_loss_list, pre_loss_list, post_loss_list, psnr_c, psnr_s, total_loss_list = [], [], [], [], [], [], []
    lam_c, lam_s, lam_f = lam   # print(lam_c)print(lam_s)print(lam_f)
    if mode != 'train':
        dataloader = datasets.validloader
        net.eval()
    else:
        dataloader = datasets.trainloader
        net.train()
    epoch_time_start = time.time()
    for i_batch, data in enumerate(dataloader):
        batch_time_start = time.time()
        # if c.pre_JPEG_attack_train_valid:
        #     data = attack([data, data])

        data = data.to(device)
        num = data.shape[0] // 2

        cover_image = data[:num]
        secret_image = data[num:num * 2]
        cover_input = dwt(cover_image)
        secret_input = dwt(secret_image)

        forward_input = torch.cat((cover_input, secret_input), 1)
        #    forward:   #
        forward_output = net(forward_input)
        output_z = forward_output.narrow(1, 4 * c.channels_in, forward_output.shape[1] - 4 * c.channels_in)
        output_z_guass = gauss_noise(output_z.shape)

        if step ==0:
            encoded_image_dwt = forward_output.narrow(1, 0, 4 * c.channels_in)
            encoded_image = iwt(encoded_image_dwt)
        if step == 1 or step == 2:
            encoder_input_dwt = torch.cat((forward_output, secret_input), dim=1)
            encoded_image_dwt = net.model_en(encoder_input_dwt)
            encoded_image = iwt(encoded_image_dwt)

        #################
        #   noise attack #

        noise_image = attack([encoded_image, cover_image])
        noise_dwt = dwt(noise_image)


        #################
        #   backward:   #
        #################
        backward_input = torch.cat((noise_dwt, output_z_guass), 1)
        backward_output = net(backward_input, rev=True)
        if step==0:
            decoded_image_dwt = backward_output.narrow(1, 4 * c.channels_in, backward_output.shape[1] - 4 * c.channels_in)
            decoded_image = iwt(decoded_image_dwt)
        if step == 1 or step == 2:
            decoded_image_dwt = net.model_de(backward_output)
            decoded_image = iwt(decoded_image_dwt)

        #################
        #     loss:     #
        #################

        c_loss = mse_loss(encoded_image, cover_image)
        s_loss = mse_loss(decoded_image, secret_image)
        if hfloss:
            f_loss = mse_loss(encoded_image_dwt.narrow(1, 0, c.channels_in), cover_input.narrow(1, 0, c.channels_in)) +\
                 mse_loss(decoded_image_dwt.narrow(1, 0, c.channels_in), secret_input.narrow(1, 0, c.channels_in))
        else:
            f_loss = 0

        decoded_image = decoded_image.clip(0, 1)
        secret_image = secret_image.clip(0, 1)
        encoded_image = encoded_image.clip(0, 1)
        cover_image = cover_image.clip(0, 1)

        psnr_temp = computePSNR(decoded_image, secret_image)
        psnr_s.append(psnr_temp)
        psnr_temp_c = computePSNR(encoded_image, cover_image)
        psnr_c.append(psnr_temp_c)

        if c.image_save_train_valid:
            cover_images_pad = F.pad(cover_image, (5, 5, 5, 5), value=1.0)
            encoded_images_pad = F.pad(encoded_image, (5, 5, 5, 5), value=1.0)
            noised_images_pad = F.pad(noise_image, (5, 5, 5, 5), value=1.0)
            secret_images_pad = F.pad(secret_image, (5, 5, 5, 5), value=1.0)
            decoded_images_pad = F.pad(decoded_image, (5, 5, 5, 5), value=1.0)
            combination_images = torch.cat((cover_images_pad, encoded_images_pad, noised_images_pad, secret_images_pad, decoded_images_pad), dim=2)
        # if step == 1:
        #     total_loss = lam_s * s_loss
        # elif step == 0 or step == 2:
        #     total_loss = lam_s * s_loss + lam_c * c_loss + lam_f * f_loss
        # print(f' lam_s = {lam_s[0]} {lam_s[1]} {lam_s[2]} | lam_c = {lam_c[0]} {lam_c[1]} {lam_c[2]} | lam_f = {lam_f[0]} {lam_f[1]} {lam_f[2]}')

        if step == 0:
            total_loss = lam_s[0] * s_loss + lam_c[0] * c_loss + lam_f[0] * f_loss
        elif step == 1:
            total_loss = lam_s[1] * s_loss + lam_c[1] * c_loss + lam_f[1] * f_loss
        elif step == 2:
            total_loss = lam_s[2] * s_loss + lam_c[2] * c_loss + lam_f[2] * f_loss
        if optim is None:
            lr = None
        else:
            lr = np.log10(optim.param_groups[0]['lr'])
        if mode == 'train':
            if c.image_save_train_valid:
                torchvision.utils.save_image(cover_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/cover/' + '00000.png')
                torchvision.utils.save_image(encoded_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/stego/' + '00000.png')
                torchvision.utils.save_image(noise_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/noise/' + '00000.png')
                torchvision.utils.save_image(secret_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/secret/' + '00000.png')
                torchvision.utils.save_image(decoded_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/secret-rev/' + '00000.png')
                if i_batch < 5:
                    torchvision.utils.save_image(combination_images,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/train/combination/' + '' + '%.d.' % i_batch + "png")

            total_loss.backward()
            optim.step()
            optim.zero_grad()

        elif mode == 'valid':
            if c.image_save_train_valid:
                torchvision.utils.save_image(cover_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/cover/' + '%.5d.png' % i_batch)
                torchvision.utils.save_image(encoded_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/stego/' + '%.5d.png' % i_batch)
                torchvision.utils.save_image(noise_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/noise/' + '%.5d.png' % i_batch)
                torchvision.utils.save_image(secret_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/secret/' + '%.5d.png' % i_batch)
                torchvision.utils.save_image(decoded_image,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/secret-rev/' + '%.5d.png' % i_batch)
                if i_batch < 20:
                    torchvision.utils.save_image(combination_images,'/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + '/images/valid/combination/' + '' + '%.d.' % i_batch + "png")
        batch_time_end = time.time()
        # print(batch_time_end-batch_time_start)
        g_loss_list.append(c_loss.item())
        r_loss_list.append(s_loss.item())
        total_loss_list.append(total_loss.item())
    psnr_s = sum(psnr_s) / len(psnr_s)
    psnr_c = sum(psnr_c) / len(psnr_c)
    epoch_time_end = time.time()
    if mode == 'train':
        print(f' train{i_epoch} | lr = {lr} | T = {epoch_time_end-epoch_time_start} | psnr_s={psnr_s} | psnr_c={psnr_c} | total_loss={total_loss} | c_loss={c_loss} | s_loss={s_loss} | f_loss={f_loss}')

    if mode == 'valid':
        print(f' valid{i_epoch} | lr = {lr} | T = {epoch_time_end-epoch_time_start} | psnr_s={psnr_s} | psnr_c={psnr_c} | total_loss={total_loss} | c_loss={c_loss} | s_loss={s_loss} | f_loss={f_loss}')

        before = 'valid'

    else:
        before = ''
    if mode != 'valid':
        writer.add_scalars(f"{before}c_loss", {f"{before}guide loss": np.mean(g_loss_list)}, i_epoch)
        writer.add_scalars(f"{before}s_loss", {f"{before}rev loss": np.mean(r_loss_list)}, i_epoch)
        writer.add_scalars(f"{before}PSNR_S", {f"{before}average psnr": np.mean(psnr_s)}, i_epoch)
        writer.add_scalars(f"{before}PSNR_C", {f"{before}average psnr": np.mean(psnr_c)}, i_epoch)
        writer.add_scalars(f"{before}Loss", {f"{before}Loss": np.mean(total_loss_list)}, i_epoch)

    return np.mean(total_loss_list)



def train(result_folder, net, step, optim, weight_scheduler, attack_method, attack, start_epoch, end_epoch, visualizer=None, expinfo='', lam=([0.0,0.0,0.0], [0.0,0.0,0.0], [0.0,0.0,0.0,]), hfloss=True):

    writer = SummaryWriter(comment=expinfo, filename_suffix="steg")
    # val_loss = train_epoch(net, step, optim, attack, start_epoch, mode='val', writer=writer, lam=lam)

    for i_epoch in range(start_epoch + 1, end_epoch + 1):

        #################
        #     train:    #
        #################
        train_loss = train_epoch(net, step, optim, attack, i_epoch, mode='train', writer=writer, lam=lam, hfloss=hfloss)
        # print(f' i_epoch={i_epoch} | train_loss={train_loss}')
        #################
        #     val:    #
        #################
        if i_epoch % c.val_freq == 0:
            with torch.no_grad():
                val_loss = train_epoch(net, step, optim, attack, i_epoch, mode='valid', writer=writer, lam=lam, hfloss=hfloss)

        # info = [np.round(train_loss, 2), np.round(val_loss, 2), np.round(np.log10(optim.param_groups[0]['lr']), 2), attack_method]
        # viz.show_loss(visualizer, info)

        if i_epoch > 0 and (i_epoch % c.SAVE_freq) == 0:
            torch.save({'opt': optim.state_dict(), 'net': net.state_dict()}, result_folder + '/models/model_checkpoint_%.5i' % i_epoch + '.pth')

        weight_scheduler.step()

    torch.save({'opt': optim.state_dict(), 'net': net.state_dict()}, f'{result_folder}/models/final_state/{expinfo}.pth')
    writer.close()

def model_init(step, load_path='', load_opt=True, forward_fusion=True, backward_fusion=True):
    net = Model(fusion_forward=forward_fusion, fusion_backward=backward_fusion)
    if step == 0:
        lr = c.lr
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = True
            elif 'enhance' in name:
                para.requires_grad = False

    elif step == 1:
        lr = c.lr
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = False
            elif 'enhance' in name:
                para.requires_grad = True
    elif step == 2:
        lr = c.lr * 0.5
        for name, para in net.named_parameters():
            if 'inbs' in name:
                para.requires_grad = True
            elif 'enhance' in name:
                para.requires_grad = True


    optim = torch.optim.Adam(filter(lambda x:x.requires_grad, net.parameters()), lr=lr, betas=c.betas, eps=1e-6, weight_decay=c.weight_decay)
    net.cuda()
    init_model(net)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, c.weight_step, gamma=c.gamma)

    if load_path != '':
        net, optim = load(net, optim, load_path, load_opt)
    return net, optim, weight_scheduler



def main(result_folder, attack_method, attack, step, load_path='', start_epoch=0, end_epoch = 1600, lam=([0.0,0.0,0.0], [0.0,0.0,0.0], [0.0,0.0,0.0]), forward_fusion=True, backward_fusion=True, hfloss=True):
    warnings.filterwarnings("ignore")
    if step == 0:
        expinfo = f'{attack_method}_hinet_pretrain'
        start_epoch = start_epoch
        end_epoch = end_epoch
    elif step == 1:
        expinfo = f'{attack_method}_enhance_pretrain'
        start_epoch = start_epoch
        end_epoch = end_epoch
    elif step == 2:
        expinfo = f'{attack_method}_enhance_finetune'
        start_epoch = start_epoch
        end_epoch = end_epoch

    if load_path == '':
        load_opt = False
        if step == 1:
            load_path = f'{result_folder}/models/final_state/{attack_method}_hinet_pretrain.pth'

        elif step == 2:
            load_path = f'{result_folder}/models/final_state/{attack_method}_enhance_pretrain.pth'
    else:
        load_opt = True


    net, optim, weight_scheduler = model_init(step=step, load_path=load_path, load_opt=load_opt, forward_fusion=forward_fusion, backward_fusion=backward_fusion)

    visualizer = viz.Visualizer(c.loss_names)
    train(result_folder, net, step, optim, weight_scheduler, attack_method, attack, start_epoch, end_epoch, visualizer, expinfo=expinfo, lam=lam, hfloss=hfloss)
    train_epoch(net, attack=attack, mode='valid', step=step, hfloss=hfloss)
    #A='results/image/train/test/cover/',B='results/image/train/test/stego/',
    #C='results/image/train/test/secret/',D='results/image/train/test/secret-rev/',
    PSNR_all_s, SSIM_all_s = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/valid',test_Y=True, secret=True, cover=False, img='png')
    # print(f' secret | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
    PSNR_all_c, SSIM_all_c = calculate_PSNR_SSIM(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/valid',test_Y=True, secret=False, cover=True, img='png')
    # print(f' cover | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
    MAE_all_s, RMSE_all_s, MAE_s = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/valid',test_Y=True, secret=True, cover=False, img='png')
    # print(f' secret | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
    MAE_all_c, RMSE_all_c, MAE_c = calculate_APD_RMSE_MAE(result_folder='/media/WRL/D/WRL/HiNet_Robust_main/' + result_folder + 'images/valid',test_Y=True, secret=False, cover=True, img='png')
    # print(f' cover | MAE_AVE={sum(MAE_all) / len(MAE_all)} | RMSE_AVE={sum(RMSE_all) / len(RMSE_all)} ')
    print(f' secret | PSNR={sum(PSNR_all_s) / len(PSNR_all_s)} | SSIM={sum(SSIM_all_s) / len(SSIM_all_s)} | MAE_AVE={sum(MAE_all_s) / len(MAE_all_s)} | RMSE_AVE={sum(RMSE_all_s) / len(RMSE_all_s)} | '
          f' cover | PSNR={sum(PSNR_all_c) / len(PSNR_all_c)} | SSIM={sum(SSIM_all_c) / len(SSIM_all_c)} | MAE_AVE={sum(MAE_all_c) / len(MAE_all_c)} | RMSE_AVE={sum(RMSE_all_c) / len(RMSE_all_c)} ')
    # calculate_PSNR_SSIM.main(f'{expinfo}')



if __name__ == '__main__':
    from utils.load_train_setting import *

    attack = Noise(noise_layers)
    attack_method = "Combined"
    result_folder = result_folder

    lambda_c_step123 = [1.0, 1.0, 1.0]
    lambda_s_step123 = [3.0, 3.5, 4.0]
    lambda_f_step123 = [0.0, 1.0, 1.0]
    lam = (lambda_c_step123, lambda_s_step123, lambda_f_step123)
    for step in range(3):
        if step == 0:
            main(result_folder, attack_method, attack, step, start_epoch=0, end_epoch=150, lam=lam, forward_fusion=forward_fusion, backward_fusion=backward_fusion, hfloss=hfloss)
        if step == 1:
            main(result_folder, attack_method, attack, step, start_epoch=150, end_epoch=300, lam=lam, forward_fusion=forward_fusion, backward_fusion=backward_fusion, hfloss=hfloss)
        if step == 2:
            main(result_folder, attack_method, attack, step, start_epoch=300, end_epoch=600, lam=lam, forward_fusion=forward_fusion, backward_fusion=backward_fusion, hfloss=hfloss)

#1 epoch --- 6min





